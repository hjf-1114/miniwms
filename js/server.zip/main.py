"""MiniWMS -- 轻量仓库管理系统（WMS）入口。

职责：
- Flask 应用创建与配置
- **中央库 / 业务库双层连接**（控制面 + 按仓容器隔离，见 scope.py）
- SQLite 连接管理（请求级连接，g 上下文）
- 数据库初始化（建表 + 列迁移）
- 聚合各业务 Blueprint

依赖：仅 Python 标准库 + Flask。
"""
import json
import os
import sqlite3

from flask import Flask, g, jsonify, redirect, request

import constants as C
import scope as S
import putaway_rules as PR

DB_PATH = os.environ.get(
    "MINIWMS_DB",
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "miniwms.db"),
)
# 中央库（控制面）：仓库主数据、货主主数据、用户角色、数据授权表。
# 业务库（数据面）：默认直接复用中央库，保证「下载下来就能用」；
# 在 warehouse.db_path 配置独立文件后，该仓的业务数据物理隔离到另一个 SQLite 文件。
CONTROL_DB_PATH = DB_PATH
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
WAREHOUSE_HEADER = "X-WMS-Warehouse"

# 按 ID 访问的资源 → (业务表, 归属列, owner_id 为 NULL 是否视为公共数据放行)。
# 集中在 before_request 做归属守门，覆盖详情 / 更新 / 删除 / 单据动作等所有端点，
# 避免逐个路由漏挂装饰器（这正是上下文切面相对「手写 WHERE」的价值）。
RESOURCE_OWNER_TABLES = {
    "owners": ("owner", "id", False),
    "products": ("product", "owner_id", True),
    "customers": ("customer", "owner_id", False),
    "suppliers": ("supplier", "owner_id", False),
    "carriers": ("carrier", "owner_id", True),
    # M31 司机 / 车辆：owner_id NULL＝全系统共享，按 ID 访问同样受货主守门
    "drivers": ("driver", "owner_id", True),
    "vehicles": ("vehicle", "owner_id", True),
    "asns": ("asn", "owner_id", False),
    "dns": ("dn", "owner_id", False),
    "transfers": ("transfer", "owner_id", False),
    "stocktakes": ("stocktake", "owner_id", False),
    "care-plans": ("care_plan", "owner_id", False),   # M37 养护计划
    "care-tasks": ("care_task", "owner_id", False),   # M37 养护任务
}
# /api/batch/<子资源>/<id> 的二级路径映射
BATCH_RESOURCE_TABLES = {
    "profiles": ("batch", "owner_id", False),
    "receipts": ("batch_receipt", "owner_id", False),
}

app = Flask(__name__, static_folder="web_app", static_url_path="")


@app.route("/")
def index():
    """从首页进入多标签工作台。"""
    return redirect("/app.html")


def _connect(path):
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def get_control_db():
    """中央库连接（控制面）。所有账号、角色、仓库主数据与授权表只认这一份。"""
    if "cdb" not in g:
        g.cdb = _connect(CONTROL_DB_PATH)
    return g.cdb


_BUSINESS_INITIALIZED = set()


def resolve_warehouse_db_path(raw):
    """把 warehouse.db_path 解析成安全绝对路径。

    空串 = 共用中央库（默认演示模式）；非空时只允许项目目录内、以 .db 结尾的文件，
    避免把任意路径配置成数据库文件。
    """
    raw = (raw or "").strip()
    if not raw:
        return ""
    p = os.path.abspath(raw if os.path.isabs(raw) else os.path.join(BASE_DIR, raw))
    try:
        inside = os.path.commonpath([BASE_DIR, p]) == BASE_DIR
    except ValueError:
        inside = False
    if not inside:
        raise S.ScopeError("仓库数据文件路径必须位于项目目录内", 400)
    if not p.lower().endswith(".db"):
        raise S.ScopeError("仓库数据文件必须以 .db 结尾", 400)
    return p


def normalize_warehouse_db_path(raw):
    """校验并返回可入库的**相对路径**（相对项目根目录），空串表示共用中央库。

    用相对路径是为了保证「换台机器 clone 下来直接能用」：绝对路径会绑死本机目录。
    """
    p = resolve_warehouse_db_path(raw)
    if not p:
        return ""
    return os.path.relpath(p, BASE_DIR).replace(os.sep, "/")


def all_business_db_paths(control=None):
    """列出需要检查的已存在库文件：中央库 + 各仓配置的独立库。

    用于仓库删除前的引用检查 —— 分库后单据可能只存在于某个仓的库里，
    只看中央库会漏判。
    """
    db = control or get_control_db()
    paths = [CONTROL_DB_PATH]
    try:
        for row in db.execute("SELECT db_path FROM warehouse WHERE db_path != ''"):
            try:
                p = resolve_warehouse_db_path(row["db_path"])
            except S.ScopeError:
                continue
            if p not in paths:
                paths.append(p)
    except Exception:
        pass
    return [p for p in paths if os.path.exists(p)]


def sync_control_tables(conn, control):
    """把中央库的「跨仓主数据」（货主 / 仓库）同步进业务库副本。

    业务表带 ``owner_id`` / ``warehouse_id`` 外键，独立库里必须存在对应主数据行，
    否则新建单据会触发外键失败。中央库是权威来源，这里只补齐缺失行、不覆盖已有行。
    """
    for table in ("owner", "warehouse"):
        local_cols = [r[1] for r in conn.execute(f"PRAGMA table_info({table})")]
        center_cols = {r[1] for r in control.execute(f"PRAGMA table_info({table})")}
        common = [c for c in local_cols if c in center_cols]
        if not common:
            continue
        collist = ",".join(common)
        marks = ",".join("?" for _ in common)
        sql = f"INSERT OR IGNORE INTO {table} ({collist}) VALUES ({marks})"
        for row in control.execute(f"SELECT {collist} FROM {table}").fetchall():
            conn.execute(sql, tuple(row))
    conn.commit()


def ensure_business_db(path):
    """首次连到某个独立仓时，把完整 DDL 幂等地建一遍（每个进程只做一次）。"""
    if path in _BUSINESS_INITIALIZED:
        return
    init_db(path)
    _BUSINESS_INITIALIZED.add(path)


def init_warehouse_db(db_path_rel):
    """配置 ``warehouse.db_path`` 时立即建库并同步跨仓主数据，返回绝对路径。

    之后切仓请求仍走 ``get_db()`` 的同一套初始化逻辑（幂等），这里只是让
    「改完配置马上能用、文件马上可见」，不必等第一次业务请求触发懒加载。
    """
    path = resolve_warehouse_db_path(db_path_rel)
    if not path or os.path.abspath(path) == os.path.abspath(CONTROL_DB_PATH):
        return ""
    ensure_business_db(path)
    conn = _connect(path)
    try:
        sync_control_tables(conn, get_control_db())
    finally:
        conn.close()
    return path


def get_db():
    """业务库连接：默认复用中央库连接；仓库配置了 db_path 时按仓选库。

    这是「连接层隔离」的唯一挂点 —— 现有 17 个 routes_* 全部只依赖 get_db()，
    因此按仓分库不需要改任何业务路由。
    """
    if "db" not in g:
        raw_path = getattr(g, "warehouse_db_path", "") or ""
        if not raw_path:
            g.db = get_control_db()
        else:
            path = resolve_warehouse_db_path(raw_path)
            if os.path.abspath(path) == os.path.abspath(CONTROL_DB_PATH):
                g.db = get_control_db()
            else:
                ensure_business_db(path)
                conn = _connect(path)
                sync_control_tables(conn, get_control_db())
                g.db = conn
    return g.db


def current_scope():
    """供业务路由读取当前请求的数据权限上下文（缺失时由 scope.py 拒绝）。"""
    return S.current_scope()


@app.teardown_appcontext
def close_db(_exc):
    db = g.pop("db", None)
    cdb = g.pop("cdb", None)
    if db is not None and db is not cdb:
        db.close()
    if cdb is not None:
        cdb.close()


@app.errorhandler(S.ScopeError)
def _scope_error(e):
    return jsonify(ok=False, error=str(e)), e.status


@app.before_request
def _bind_scope():
    """每个 API 请求绑定数据权限上下文与当前仓库（A 作业视角：一次只看一个仓）。

    静态页面不参与门禁，保证登录页 / 工作台始终可打开；登录与上下文自检端点
    使用「软解析」，受限时返回最小权限上下文而不是直接报错。
    """
    if not request.path.startswith("/api/"):
        g.scope = None
        g.warehouse_id = None
        g.warehouse_db_path = ""
        return

    from auth import get_current_user

    control = get_control_db()
    user = get_current_user()
    try:
        s = S.resolve_scope(user, control)
    except S.ScopeError as e:
        if request.path in S.OPEN_API_PATHS:
            s = S.denied_scope(str(e))
        else:
            return jsonify(ok=False, error=str(e)), e.status
    g.scope = s
    g.current_user = user
    try:
        row = S.check_warehouse_access(s, request.headers.get(WAREHOUSE_HEADER), control)
    except S.ScopeError as e:
        # 自检 / 登录端点允许带着「已失效的旧仓」进来，由前端据此重选；
        # 业务端点一律拒绝，避免用失效上下文绕过仓库校验。
        if request.path in S.OPEN_API_PATHS:
            row = None
        else:
            return jsonify(ok=False, error=str(e)), e.status
    g.warehouse_id = row["id"] if row is not None else None
    g.warehouse_db_path = (row["db_path"] if row is not None else "") or ""

    # ── 货主 × 仓库业务关系（格子）：与账号授权取交集，原地收紧 g.scope ──
    # s 与 g.scope 是同一 dict；授权层先解析、格子层再收紧，顺序不能反。
    g.scope = S.apply_owner_warehouse_grid(s, control, g.warehouse_id)

    # ── 写路径守门：请求体里带 owner_id 时，必须落在授权货主集合内 ──
    if request.method in ("POST", "PUT", "PATCH"):
        body = request.get_json(silent=True)
        if not isinstance(body, dict) and request.form:
            body = dict(request.form)
        if isinstance(body, dict) and body.get("owner_id") not in (None, ""):
            try:
                S.assert_owner_allowed(s, body["owner_id"])
            except S.ScopeError as e:
                return jsonify(ok=False, error=str(e)), e.status

    # ── 按 ID 访问的资源归属守门 ──
    parts = request.path.strip("/").split("/")
    spec, doc_id = None, None
    if len(parts) >= 3 and parts[0] == "api" and parts[2].isdigit():
        spec, doc_id = RESOURCE_OWNER_TABLES.get(parts[1]), parts[2]
    elif (len(parts) >= 4 and parts[0] == "api" and parts[1] == "batch"
          and parts[2] in BATCH_RESOURCE_TABLES and parts[3].isdigit()):
        spec, doc_id = BATCH_RESOURCE_TABLES[parts[2]], parts[3]
    if spec:
        table, column, allow_null = spec
        # 货主主数据是控制面权威数据，归属守门也查中央库，避免业务库副本滞后导致漏判
        reader = get_control_db() if parts[1] == "owners" else get_db()
        try:
            rec = reader.execute(
                f"SELECT {column} AS v FROM {table} WHERE id = ?", (int(doc_id),)
            ).fetchone()
        except Exception:
            rec = None  # 表不存在等异常交给路由自身返回 404，不在守门层改语义
        if rec is not None and not s.get("owner_all"):
            v = rec["v"]
            if v is None and not allow_null:
                return jsonify(ok=False, error="无权操作该货主的数据"), 403
            try:
                if v is not None:
                    S.assert_owner_allowed(s, v)
            except S.ScopeError as e:
                return jsonify(ok=False, error=str(e)), e.status


def _seed_auth(conn):
    """初始化默认角色（管理员/操作员/只读）与 admin 账号（仅空库时）。"""
    from auth import hash_password

    if conn.execute("SELECT COUNT(*) FROM role").fetchone()[0] == 0:
        roles = {
            "管理员": ["*"],
            "操作员": ["owner:*", "product:*", "location:*", "customer:*", "asn:*", "dn:*", "stock:read"],
            "只读": ["owner:read", "product:read", "location:read", "customer:read", "asn:read", "dn:read", "stock:read"],
        }
        for name, perms in roles.items():
            conn.execute(
                "INSERT INTO role (name, permissions, created_at, updated_at) "
                "VALUES (?, ?, datetime('now','localtime'), datetime('now','localtime'))",
                (name, json.dumps(perms)),
            )
        conn.commit()
    if conn.execute("SELECT COUNT(*) FROM user").fetchone()[0] == 0:
        salt, h = hash_password("admin123")
        admin_role = conn.execute("SELECT id FROM role WHERE name = ?", ("管理员",)).fetchone()[0]
        # 管理员显式授予 ALL：ALL 必须是授权解析后显式给出的标志，
        # 不能靠「角色名叫管理员」或「上下文缺失」隐式放行。
        conn.execute(
            "INSERT INTO user (username, password_salt, password_hash, role_id, status, "
            "warehouse_scope, owner_scope, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, 'active', 'all', 'all', "
            "datetime('now','localtime'), datetime('now','localtime'))",
            ("admin", salt, h, admin_role),
        )
        conn.commit()


def request_payload():
    """统一取参：优先 JSON，退回表单。"""
    return request.get_json(silent=True) or request.form or {}


def gen_doc_no(db, table, prefix):
    """生成业务单号：前缀-YYYYMMDD-NNN（当日前缀下计数 +1，3 位补零）。

    留空单号时调用；创建接口传入 code 则优先用传入值，实现「英文开头 + 日期流水号」。
    """
    import datetime

    day = datetime.date.today().strftime("%Y%m%d")
    like = f"{prefix}-{day}-%"
    n = db.execute(f"SELECT COUNT(*) AS n FROM {table} WHERE code LIKE ?", (like,)).fetchone()["n"]
    return f"{prefix}-{day}-{n + 1:03d}"


def _migrate_m20_columns(conn):
    """M20 幂等列迁移：库位挂仓库/储区 + 混放开关、货品加推荐储区、
    ASN/DN 加 4 个单据标识位与 external_doc_type（阶段 B）。

    混放字段在 location 上允许 NULL，表示「继承所属储区」；zone 上是 0/1 实值。
    单据标识位一律 0/1 并带默认值，老库补列后旧单据自动为 0 / 空串。
    """
    doc_cols = [
        ("is_virtual", "INTEGER NOT NULL DEFAULT 0"),
        ("is_direct", "INTEGER NOT NULL DEFAULT 0"),
        ("is_cold_chain", "INTEGER NOT NULL DEFAULT 0"),
        ("is_hazard", "INTEGER NOT NULL DEFAULT 0"),
        ("external_doc_type", "TEXT NOT NULL DEFAULT ''"),
    ]
    wanted = {
        "location": [
            ("zone_id", "INTEGER REFERENCES zone(id)"),
            ("warehouse_id", "INTEGER REFERENCES warehouse(id)"),
            ("allow_mix_product", "INTEGER"),
            ("allow_mix_batch", "INTEGER"),
            ("allow_mix_owner", "INTEGER"),
        ],
        "product": [("default_zone_id", "INTEGER REFERENCES zone(id)")],
        "asn": doc_cols,
        "dn": doc_cols,
    }
    for table, cols in wanted.items():
        exists = {r[1] for r in conn.execute(f"PRAGMA table_info({table})")}
        for name, ddl in cols:
            if name not in exists:
                conn.execute(f"ALTER TABLE {table} ADD COLUMN {name} {ddl}")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_location_zone_id ON location(zone_id)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_location_warehouse ON location(warehouse_id)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_product_default_zone ON product(default_zone_id)")


def _seed_zones(conn):
    """播种预置储区：3 个全仓共享 + 每个仓库一个常温默认区（幂等，不覆盖用户改动）。"""
    shared = (
        ("ZONE-SHARED", "全仓共享默认区", "常温"),
        ("ZONE-COLD", "冷藏区", "冷藏"),
        ("ZONE-NG", "不合格隔离区", "常温"),
    )
    for code, name, temp in shared:
        conn.execute(
            "INSERT OR IGNORE INTO zone (code, name, warehouse_id, temp_class, "
            "allow_mix_product, allow_mix_batch, allow_mix_owner, status, note) "
            "VALUES (?, ?, NULL, ?, 0, 0, 0, 'active', '')",
            (code, name, temp),
        )
    for wh in conn.execute("SELECT id, code FROM warehouse").fetchall():
        conn.execute(
            "INSERT OR IGNORE INTO zone (code, name, warehouse_id, temp_class, "
            "allow_mix_product, allow_mix_batch, allow_mix_owner, status, note) "
            "VALUES (?, ?, ?, '常温', 0, 0, 0, 'active', '')",
            (f"ZONE-{wh[1]}-DEFAULT", f"{wh[1]} 默认储区", wh[0]),
        )


def _migrate_scope_columns(conn):
    """数据权限升级（幂等）：仓库数据文件路径、承运商归属货主、用户授权范围。

    - ``warehouse.db_path``：空 = 共用中央库；非空 = 该仓业务数据物理隔离到独立文件
    - ``carrier.owner_id``：NULL = 全系统共享物流资源；非空 = 归属货主，可按货主管控
    - ``user.warehouse_scope / owner_scope``：``all``=全部、``grant``=按授权表
    - 两张授权表：账号可看哪些仓 / 哪些货主（支持「部分」也支持「全部」）
    - ``owner_warehouse``：货主在哪些仓**有业务关系**（格子），用来消掉
      「可见仓 × 可见货主」里业务上并不存在的组合；空表 = 功能未启用，老库零影响

    老库升级时只给既有 admin 一次性显式 ALL，其余账号保持 ``grant`` 最小权限；
    列已存在时不再 UPDATE，避免覆盖管理员后续收紧的授权。
    """
    cols = {r[1] for r in conn.execute("PRAGMA table_info(warehouse)")}
    if "db_path" not in cols:
        conn.execute("ALTER TABLE warehouse ADD COLUMN db_path TEXT NOT NULL DEFAULT ''")
    cols = {r[1] for r in conn.execute("PRAGMA table_info(carrier)")}
    if "owner_id" not in cols:
        conn.execute("ALTER TABLE carrier ADD COLUMN owner_id INTEGER REFERENCES owner(id)")
    # 新库 CREATE 自带该列、旧库刚 ALTER 补列，两种情况下索引都在此统一创建
    conn.execute("CREATE INDEX IF NOT EXISTS idx_carrier_owner ON carrier(owner_id)")
    cols = {r[1] for r in conn.execute("PRAGMA table_info(user)")}
    upgraded = False
    if "warehouse_scope" not in cols:
        conn.execute(
            "ALTER TABLE user ADD COLUMN warehouse_scope TEXT NOT NULL DEFAULT 'grant'"
        )
        upgraded = True
    if "owner_scope" not in cols:
        conn.execute(
            "ALTER TABLE user ADD COLUMN owner_scope TEXT NOT NULL DEFAULT 'grant'"
        )
        upgraded = True
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS user_warehouse_grant (
            user_id      INTEGER NOT NULL REFERENCES user(id) ON DELETE CASCADE,
            warehouse_id INTEGER NOT NULL REFERENCES warehouse(id) ON DELETE CASCADE,
            PRIMARY KEY (user_id, warehouse_id)
        );
        CREATE TABLE IF NOT EXISTS user_owner_grant (
            user_id  INTEGER NOT NULL REFERENCES user(id) ON DELETE CASCADE,
            owner_id INTEGER NOT NULL REFERENCES owner(id) ON DELETE CASCADE,
            PRIMARY KEY (user_id, owner_id)
        );
        CREATE TABLE IF NOT EXISTS owner_warehouse (
            owner_id     INTEGER NOT NULL REFERENCES owner(id) ON DELETE CASCADE,
            warehouse_id INTEGER NOT NULL REFERENCES warehouse(id) ON DELETE CASCADE,
            status       TEXT    NOT NULL DEFAULT 'active',
            note         TEXT    NOT NULL DEFAULT '',
            created_at   TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
            PRIMARY KEY (owner_id, warehouse_id)
        );
        CREATE INDEX IF NOT EXISTS idx_owner_warehouse_wh
            ON owner_warehouse(warehouse_id, status);
        """
    )
    if upgraded:
        conn.execute(
            "UPDATE user SET warehouse_scope = 'all', owner_scope = 'all' "
            "WHERE username = 'admin'"
        )


def _migrate_m21_columns(conn):
    """M21 批次级库存明细层：新表 + 流水 9 列 + 一次性回填（幂等）。

    - ``stock_batch`` 明细层；``stock`` 汇总层列与唯一键**永不修改**（I1 原样保持）
    - ``batch_location``：上架拆多库位时的批次实物分布
    - ``stock_movement`` 扩 9 列，全部有默认值，老流水自动填 ``''`` / ``0`` / ``NULL``
    - 回填只在明细层为空时执行一次：历史流水统一归到 ``LEGACY-UNKNOWN`` 占位维度，
      按流水聚合生成明细行，再把汇总层与明细层的差额补齐，保证 I2 / I3 立即通过。
      **不做灰度豁免**，任何不一致都会被 ``/api/stock/batch-reconcile`` 判为 false。
    """
    # init_db() 用裸 sqlite3.connect（tuple），回填与明细 upsert 需要按列名取值
    conn.row_factory = sqlite3.Row
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS stock_batch (
            id                      INTEGER PRIMARY KEY AUTOINCREMENT,
            owner_id                INTEGER NOT NULL REFERENCES owner(id),
            product_id              INTEGER NOT NULL REFERENCES product(id),
            location_id             INTEGER NOT NULL REFERENCES location(id),
            batch_no                TEXT    NOT NULL DEFAULT '',
            batch_key               TEXT    NOT NULL DEFAULT '',
            internal_batch_no       TEXT    NOT NULL DEFAULT '',
            designated_customer_id  INTEGER,
            goods_property          TEXT    NOT NULL DEFAULT '',
            stock_status            TEXT    NOT NULL DEFAULT '',
            expiry_date             TEXT    NOT NULL DEFAULT '',
            production_date         TEXT    NOT NULL DEFAULT '',
            qty                     REAL    NOT NULL DEFAULT 0,
            allocated_qty           REAL    NOT NULL DEFAULT 0,
            updated_at              TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
        );
        CREATE UNIQUE INDEX IF NOT EXISTS uq_stock_batch ON stock_batch (
            owner_id, product_id, location_id, batch_no, batch_key,
            IFNULL(designated_customer_id, 0), goods_property, stock_status
        );
        CREATE INDEX IF NOT EXISTS idx_stock_batch_loc ON stock_batch (
            owner_id, product_id, location_id
        );
        CREATE INDEX IF NOT EXISTS idx_stock_batch_no ON stock_batch (batch_no);
        CREATE TABLE IF NOT EXISTS batch_location (
            id               INTEGER PRIMARY KEY AUTOINCREMENT,
            batch_no         TEXT    NOT NULL,
            owner_id         INTEGER NOT NULL,
            product_id       INTEGER NOT NULL,
            from_location_id INTEGER,
            to_location_id   INTEGER NOT NULL,
            qty              REAL    NOT NULL,
            asn_id           INTEGER,
            asn_line_id      INTEGER,
            ref_type         TEXT    NOT NULL DEFAULT '',
            ref_id           INTEGER,
            created_at       TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
        );
        CREATE INDEX IF NOT EXISTS idx_batch_location_no ON batch_location (batch_no);
        """
    )
    cols = {r[1] for r in conn.execute("PRAGMA table_info(stock_movement)")}
    additions = (
        ("batch_no", "TEXT NOT NULL DEFAULT ''"),
        ("batch_key", "TEXT NOT NULL DEFAULT ''"),
        ("internal_batch_no", "TEXT NOT NULL DEFAULT ''"),
        ("designated_customer_id", "INTEGER"),
        ("goods_property", "TEXT NOT NULL DEFAULT ''"),
        ("stock_status", "TEXT NOT NULL DEFAULT ''"),
        ("expiry_date", "TEXT NOT NULL DEFAULT ''"),
        ("allocated_delta", "REAL NOT NULL DEFAULT 0"),
        ("operator", "TEXT NOT NULL DEFAULT ''"),
    )
    for name, decl in additions:
        if name not in cols:
            conn.execute(f"ALTER TABLE stock_movement ADD COLUMN {name} {decl}")

    # ── 一次性回填 ──
    from inventory_service import (LEGACY_BATCH_NO, align_stock_batch,
                                   legacy_dims, upsert_stock_batch)

    if conn.execute("SELECT COUNT(*) FROM stock_batch").fetchone()[0] == 0:
        conn.execute(
            "UPDATE stock_movement SET batch_no = ? WHERE batch_no = ''",
            (LEGACY_BATCH_NO,),
        )
        for r in conn.execute(
            """SELECT owner_id, product_id, location_id, batch_no, batch_key,
                      internal_batch_no, designated_customer_id, goods_property,
                      stock_status, expiry_date,
                      SUM(qty_delta) AS q, SUM(allocated_delta) AS a
               FROM stock_movement
               GROUP BY owner_id, product_id, location_id, batch_no, batch_key,
                        internal_batch_no, designated_customer_id, goods_property,
                        stock_status, expiry_date"""
        ).fetchall():
            upsert_stock_batch(
                conn, r["owner_id"], r["product_id"], r["location_id"],
                {k: r[k] for k in (
                    "batch_no", "batch_key", "internal_batch_no",
                    "designated_customer_id", "goods_property",
                    "stock_status", "expiry_date")},
                r["q"], r["a"],
            )
        # 无流水但有余额（含零行保留）也要有明细，并让 allocated 双层对齐
        for s in conn.execute(
            "SELECT owner_id, product_id, location_id, qty, allocated_qty FROM stock"
        ).fetchall():
            key = (s["owner_id"], s["product_id"], s["location_id"])
            align_stock_batch(conn, *key, s["qty"], s["allocated_qty"])
            # 明细层同样零行保留：qty=0 的汇总行也要有一条占位明细
            has = conn.execute(
                "SELECT 1 FROM stock_batch WHERE owner_id = ? AND product_id = ? "
                "AND location_id = ? LIMIT 1", key,
            ).fetchone()
            if has is None:
                upsert_stock_batch(conn, key[0], key[1], key[2], legacy_dims(), 0, 0)


def _ensure_columns(conn, table, additions):
    """幂等补列：老库与新建库执行同一段迁移，不依赖「库是否是新版创建」。"""
    cols = {r[1] for r in conn.execute(f"PRAGMA table_info({table})")}
    for name, decl in additions:
        if name not in cols:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {name} {decl}")


def _migrate_asn_counts(conn):
    """解除点收与货位的绑定，保留历史记录 ID 和验收外键。"""
    columns = {row[1]: row for row in conn.execute("PRAGMA table_info(asn_receiving_count)")}
    if columns["location_id"][3]:
        conn.executescript("""
            BEGIN IMMEDIATE;
            CREATE TABLE asn_receiving_count_new (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                asn_line_id INTEGER NOT NULL REFERENCES asn_line(id) ON DELETE CASCADE,
                location_id INTEGER REFERENCES location(id) ON DELETE SET NULL,
                qty REAL NOT NULL CHECK (qty > 0),
                accepted_qty REAL NOT NULL DEFAULT 0,
                cancelled_qty REAL NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
            );
            INSERT INTO asn_receiving_count_new
                (id, asn_line_id, location_id, qty, accepted_qty, created_at)
            SELECT id, asn_line_id, location_id, qty, accepted_qty, created_at
                FROM asn_receiving_count;
            DROP TABLE asn_receiving_count;
            ALTER TABLE asn_receiving_count_new RENAME TO asn_receiving_count;
            CREATE INDEX idx_asn_receiving_count_line ON asn_receiving_count(asn_line_id);
            COMMIT;
        """)
    _ensure_columns(conn, "asn_receiving_count", (
        ("cancelled_qty", "REAL NOT NULL DEFAULT 0"),
        ("operator", "TEXT NOT NULL DEFAULT ''"),
    ))
    if "cancelled_qty" not in {row[1] for row in conn.execute("PRAGMA table_info(asn_line)")}:
        conn.execute("ALTER TABLE asn_line ADD COLUMN cancelled_qty REAL NOT NULL DEFAULT 0")
        conn.execute("""
            UPDATE asn_line SET cancelled_qty = MAX(0, expected_qty - received_qty)
            WHERE asn_id IN (SELECT id FROM asn WHERE status = ?)
        """, (C.ASN_CANCELLED,))
    _ensure_columns(conn, "batch_location", (
        ("receipt_id", "INTEGER REFERENCES batch_receipt(id) ON DELETE SET NULL"),
        ("operator", "TEXT NOT NULL DEFAULT ''"),
        ("override_reason", "TEXT NOT NULL DEFAULT ''"),
    ))
    conn.execute("""
        CREATE TABLE IF NOT EXISTS asn_cancellation (
            id INTEGER PRIMARY KEY,
            asn_line_id INTEGER NOT NULL REFERENCES asn_line(id) ON DELETE CASCADE,
            action TEXT NOT NULL,
            qty REAL NOT NULL,
            operator TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
        )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_asn_cancellation_line ON asn_cancellation(asn_line_id)")


def _migrate_m22(conn):
    """M22 库存调整单 / 盘点方案 DDL + 盘点明细行批次维度（幂等）。

    ``stocktake_line`` 老表的表级 UNIQUE 只有 3 列，SQLite 无法 ALTER CONSTRAINT；
    检测到旧定义时按「建新表 → 复制（batch_no=''）→ 删旧表」重建，历史行不丢。
    """
    conn.row_factory = sqlite3.Row
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS stock_adjustment (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            code         TEXT    NOT NULL UNIQUE,
            source_type  TEXT    NOT NULL DEFAULT 'manual',
            source_id    INTEGER,
            reason_code  TEXT    NOT NULL DEFAULT '',
            status       TEXT    NOT NULL DEFAULT 'draft',
            creator      TEXT    NOT NULL DEFAULT '',
            approver     TEXT    NOT NULL DEFAULT '',
            created_at   TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
            approved_at  TEXT    NOT NULL DEFAULT '',
            note         TEXT    NOT NULL DEFAULT ''
        );
        CREATE INDEX IF NOT EXISTS idx_adjustment_status ON stock_adjustment(status);
        CREATE INDEX IF NOT EXISTS idx_adjustment_source ON stock_adjustment(source_type, source_id);
        CREATE TABLE IF NOT EXISTS stock_adjustment_line (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            adjustment_id  INTEGER NOT NULL REFERENCES stock_adjustment(id) ON DELETE CASCADE,
            owner_id       INTEGER NOT NULL,
            product_id     INTEGER NOT NULL,
            location_id    INTEGER NOT NULL,
            batch_no       TEXT    NOT NULL DEFAULT '',
            delta_qty      REAL    NOT NULL,
            qty_before     REAL    NOT NULL DEFAULT 0,
            reason         TEXT    NOT NULL DEFAULT ''
        );
        CREATE INDEX IF NOT EXISTS idx_adjustment_line_adj ON stock_adjustment_line(adjustment_id);
        CREATE TABLE IF NOT EXISTS stocktake_plan (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            code          TEXT    NOT NULL UNIQUE,
            name          TEXT    NOT NULL,
            scope_type    TEXT    NOT NULL DEFAULT 'full',
            scope         TEXT    NOT NULL DEFAULT '{}',
            blind_mode    TEXT    NOT NULL DEFAULT 'hide_book',
            dynamic_baseline TEXT NOT NULL DEFAULT 'last_closed',
            lookback_days INTEGER NOT NULL DEFAULT 7,
            movement_from TEXT    NOT NULL DEFAULT '',
            movement_to   TEXT    NOT NULL DEFAULT '',
            movement_types TEXT   NOT NULL DEFAULT '[]',
            auto_adjust   INTEGER NOT NULL DEFAULT 0,
            include_zero  INTEGER NOT NULL DEFAULT 0,
            enabled       INTEGER NOT NULL DEFAULT 1,
            note          TEXT    NOT NULL DEFAULT '',
            created_at    TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
            updated_at    TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
        );
        """
    )
    _ensure_columns(conn, "stocktake", (
        ("plan_id", "INTEGER"),
        ("scope_type", "TEXT NOT NULL DEFAULT 'full'"),
        ("blind_mode", "TEXT NOT NULL DEFAULT 'none'"),
        ("config_override", "TEXT NOT NULL DEFAULT '{}'"),
        ("scope_snapshot", "TEXT NOT NULL DEFAULT '{}'"),
        ("adjustment_id", "INTEGER"),
        ("closed_at", "TEXT NOT NULL DEFAULT ''"),
    ))
    old = conn.execute(
        "SELECT sql FROM sqlite_master WHERE type='table' AND name='stocktake_line'"
    ).fetchone()
    if old is not None and "batch_no" not in (old[0] or ""):
        conn.executescript(
            """
            ALTER TABLE stocktake_line RENAME TO stocktake_line_m22_old;
            CREATE TABLE stocktake_line (
                id               INTEGER PRIMARY KEY AUTOINCREMENT,
                stocktake_id     INTEGER NOT NULL REFERENCES stocktake(id),
                owner_id         INTEGER NOT NULL REFERENCES owner(id),
                product_id       INTEGER NOT NULL REFERENCES product(id),
                location_id      INTEGER NOT NULL REFERENCES location(id),
                batch_no         TEXT    NOT NULL DEFAULT '',
                book_qty         REAL    NOT NULL DEFAULT 0,
                counted_qty      REAL    DEFAULT NULL,
                UNIQUE(stocktake_id, product_id, location_id, batch_no)
            );
            INSERT INTO stocktake_line
                (id, stocktake_id, owner_id, product_id, location_id,
                 batch_no, book_qty, counted_qty)
            SELECT id, stocktake_id, owner_id, product_id, location_id,
                   '', book_qty, counted_qty FROM stocktake_line_m22_old;
            DROP TABLE stocktake_line_m22_old;
            CREATE INDEX IF NOT EXISTS idx_stocktake_line_st ON stocktake_line(stocktake_id);
            """
        )


def _migrate_m23(conn):
    """M23 指定客户专属库存 / 销退口径 DDL（幂等补列，老库零迁移成本）。

    * ``asn.external_batch_no``：销退单头登记外部传入的原内部批次号，作为明细行默认值。
    * ``batch_receipt`` 三列：指定客户、外部批次号、缺号告警。
    * ``customer_reservation_log``：M23 补充的风险放行审计表（幂等建表 + 两个索引）。
    新库 DDL 已带这些列，老库由 ``_ensure_columns`` 补齐，两条路径执行同一套语义。
    """
    _ensure_columns(conn, "asn", (
        ("external_batch_no", "TEXT NOT NULL DEFAULT ''"),
    ))
    _ensure_columns(conn, "batch_receipt", (
        ("designated_customer_id", "INTEGER"),
        ("external_batch_no", "TEXT NOT NULL DEFAULT ''"),
        ("warning", "TEXT NOT NULL DEFAULT ''"),
    ))
    # M23 补充（用户 2026-11-09 二次确认）：专属库存发给其他客户允许继续，
    # 但每次风险放行都要留痕。只建审计表，不参与任何拦截判断。
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS customer_reservation_log (
            id                      INTEGER PRIMARY KEY AUTOINCREMENT,
            dn_id                   INTEGER NOT NULL,
            dn_code                 TEXT    NOT NULL DEFAULT '',
            dn_customer_id          INTEGER,
            owner_id                INTEGER NOT NULL,
            product_id              INTEGER NOT NULL,
            location_id             INTEGER NOT NULL,
            batch_no                TEXT    NOT NULL DEFAULT '',
            designated_customer_id  INTEGER,
            qty                     REAL    NOT NULL DEFAULT 0,
            code                    TEXT    NOT NULL DEFAULT '',
            reason                  TEXT    NOT NULL DEFAULT '',
            action                  TEXT    NOT NULL DEFAULT 'risk_allowed',
            acknowledged            INTEGER NOT NULL DEFAULT 0,
            operator                TEXT    NOT NULL DEFAULT '',
            created_at              TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
        );
        CREATE INDEX IF NOT EXISTS idx_resv_log_dn    ON customer_reservation_log(dn_id);
        CREATE INDEX IF NOT EXISTS idx_resv_log_owner ON customer_reservation_log(owner_id);
        """
    )


def _migrate_m24(conn):
    """M24 库存转移单：三张幂等表（老库零迁移成本）。

    * ``inventory_transfer`` 单据头（无 owner_id，按明细行货主做隔离，与 M22 调整单一致）
    * ``inventory_transfer_line`` 源维度 → 目标维度 + 数量快照；A1 口径下库位单一
    * ``inventory_change_log`` 字段级变更文档（库存事务管「量」，变更文档管「属性」）
    """
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS inventory_transfer (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            code            TEXT    NOT NULL UNIQUE,
            transfer_type   TEXT    NOT NULL,
            reason_code     TEXT    NOT NULL DEFAULT '',
            status          TEXT    NOT NULL DEFAULT 'draft',
            reversal_of_id  INTEGER,
            creator         TEXT    NOT NULL DEFAULT '',
            allocator       TEXT    NOT NULL DEFAULT '',
            approver        TEXT    NOT NULL DEFAULT '',
            closer          TEXT    NOT NULL DEFAULT '',
            business_at     TEXT    NOT NULL DEFAULT '',
            created_at      TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
            allocated_at    TEXT    NOT NULL DEFAULT '',
            approved_at     TEXT    NOT NULL DEFAULT '',
            closed_at       TEXT    NOT NULL DEFAULT '',
            note            TEXT    NOT NULL DEFAULT ''
        );
        CREATE INDEX IF NOT EXISTS idx_it_status ON inventory_transfer(status);
        CREATE INDEX IF NOT EXISTS idx_it_type   ON inventory_transfer(transfer_type);

        CREATE TABLE IF NOT EXISTS inventory_transfer_line (
            id                          INTEGER PRIMARY KEY AUTOINCREMENT,
            transfer_id                 INTEGER NOT NULL REFERENCES inventory_transfer(id) ON DELETE CASCADE,
            owner_id                    INTEGER NOT NULL,
            product_id                  INTEGER NOT NULL,
            location_id                 INTEGER NOT NULL,
            stock_batch_id              INTEGER,
            from_batch_no               TEXT NOT NULL DEFAULT '',
            from_batch_key              TEXT NOT NULL DEFAULT '',
            from_internal_batch_no      TEXT NOT NULL DEFAULT '',
            from_designated_customer_id INTEGER,
            from_goods_property         TEXT NOT NULL DEFAULT '',
            from_stock_status           TEXT NOT NULL DEFAULT '',
            from_expiry_date            TEXT NOT NULL DEFAULT '',
            from_production_date        TEXT NOT NULL DEFAULT '',
            to_batch_no                 TEXT NOT NULL DEFAULT '',
            to_batch_key                TEXT NOT NULL DEFAULT '',
            to_internal_batch_no        TEXT NOT NULL DEFAULT '',
            to_designated_customer_id   INTEGER,
            to_goods_property           TEXT NOT NULL DEFAULT '',
            to_stock_status             TEXT NOT NULL DEFAULT '',
            to_expiry_date              TEXT NOT NULL DEFAULT '',
            to_production_date          TEXT NOT NULL DEFAULT '',
            qty                         REAL NOT NULL DEFAULT 0,
            qty_before                  REAL NOT NULL DEFAULT 0,
            qty_after                   REAL NOT NULL DEFAULT 0,
            allocated                   INTEGER NOT NULL DEFAULT 0
        );
        CREATE INDEX IF NOT EXISTS idx_itl_transfer ON inventory_transfer_line(transfer_id);
        CREATE INDEX IF NOT EXISTS idx_itl_owner    ON inventory_transfer_line(owner_id);

        CREATE TABLE IF NOT EXISTS inventory_change_log (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            transfer_id  INTEGER NOT NULL REFERENCES inventory_transfer(id) ON DELETE CASCADE,
            line_id      INTEGER,
            object_type  TEXT NOT NULL DEFAULT 'stock_batch',
            object_id    INTEGER,
            field_name   TEXT NOT NULL,
            old_value    TEXT NOT NULL DEFAULT '',
            new_value    TEXT NOT NULL DEFAULT '',
            operator     TEXT NOT NULL DEFAULT '',
            approver     TEXT NOT NULL DEFAULT '',
            business_at  TEXT NOT NULL DEFAULT '',
            system_at    TEXT NOT NULL DEFAULT (datetime('now','localtime')),
            reason_code  TEXT NOT NULL DEFAULT ''
        );
        CREATE INDEX IF NOT EXISTS idx_icl_transfer ON inventory_change_log(transfer_id);
        """
    )


def _migrate_m25(conn):
    """M25 上架推荐规则引擎：三张幂等表（老库零迁移成本）。

    * ``putaway_rule_set`` 策略包头（货主×仓库精确 > 仓库默认 > 系统默认）
    * ``putaway_rule`` 规则行：13 维条件组 / fallback 链 / limits / 评分权重；
      带 ``rule_type``，M35 出库分配规则复用同一张表（用户 3A）
    * ``putaway_recommendation`` 推荐日志，供 M26 统计命中率 / 驳回率
    """
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS putaway_rule_set (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            code          TEXT    NOT NULL UNIQUE,
            name          TEXT    NOT NULL,
            warehouse_id  INTEGER REFERENCES warehouse(id),
            owner_id      INTEGER REFERENCES owner(id),
            status        TEXT    NOT NULL DEFAULT 'active',
            note          TEXT    NOT NULL DEFAULT '',
            created_at    TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
            updated_at    TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
        );
        CREATE INDEX IF NOT EXISTS idx_prs_status ON putaway_rule_set(status);

        CREATE TABLE IF NOT EXISTS putaway_rule (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            rule_set_id  INTEGER NOT NULL REFERENCES putaway_rule_set(id) ON DELETE CASCADE,
            rule_type    TEXT    NOT NULL DEFAULT 'putaway',
            priority     INTEGER NOT NULL DEFAULT 10,
            name         TEXT    NOT NULL,
            condition    TEXT    NOT NULL DEFAULT '{}',
            steps        TEXT    NOT NULL DEFAULT '[]',
            limits       TEXT    NOT NULL DEFAULT '{}',
            score        TEXT    NOT NULL DEFAULT '{}',
            enabled      INTEGER NOT NULL DEFAULT 1,
            note         TEXT    NOT NULL DEFAULT '',
            created_at   TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
            updated_at   TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
            UNIQUE (rule_set_id, rule_type, priority, name)
        );
        CREATE INDEX IF NOT EXISTS idx_pr_set      ON putaway_rule(rule_set_id, enabled);
        CREATE INDEX IF NOT EXISTS idx_pr_type     ON putaway_rule(rule_type, priority);

        CREATE TABLE IF NOT EXISTS putaway_recommendation (
            id                  INTEGER PRIMARY KEY AUTOINCREMENT,
            asn_id              INTEGER NOT NULL,
            asn_line_id         INTEGER NOT NULL,
            rule_set_id         INTEGER,
            rule_id             INTEGER,
            hit_priority        INTEGER,
            hit_step            INTEGER,
            top_json            TEXT NOT NULL DEFAULT '[]',
            chosen_location_id  INTEGER,
            action              TEXT NOT NULL DEFAULT 'preview',
            operator            TEXT NOT NULL DEFAULT '',
            override_reason     TEXT NOT NULL DEFAULT '',
            created_at          TEXT NOT NULL DEFAULT (datetime('now','localtime'))
        );
        CREATE INDEX IF NOT EXISTS idx_prec_asn    ON putaway_recommendation(asn_id);
        CREATE INDEX IF NOT EXISTS idx_prec_action ON putaway_recommendation(action);
        """
    )


def _migrate_m26(conn):
    """M26 外部单据类别字典（v3.3 4A 两步法第二步）。

    设计 §8.4：M20 只做自由文本字段，M26 再补可配字典（code / 名称 / 启用 /
    默认目标储区）。字典**不反写** ``asn.external_doc_type``、不做强制枚举校验：
    老单据里的自由文本仍然合法，字典只供编辑器与条件组下拉取值使用。
    """
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS external_doc_type_dict (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            code            TEXT    NOT NULL UNIQUE,
            name            TEXT    NOT NULL,
            enabled         INTEGER NOT NULL DEFAULT 1,
            default_zone_id INTEGER,
            note            TEXT    NOT NULL DEFAULT '',
            created_at      TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
            updated_at      TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
        );
        CREATE INDEX IF NOT EXISTS idx_edt_enabled ON external_doc_type_dict(enabled);
        """
    )
    for code, name in C.EXTERNAL_DOC_TYPE_DICT_SEED:
        conn.execute(
            "INSERT OR IGNORE INTO external_doc_type_dict (code, name, note) "
            "VALUES (?, ?, ?)", (code, name, "M26 种子字典，可在规则配置页维护"),
        )


def _migrate_m35(conn):
    """M35 出库波次分配：``dn_pick`` 扩批次维度 / 波次号，新增分配留痕日志。

    老库逐列 ALTER：历史 ``dn_pick`` 行的批次列全部为空字符串，``ship()`` 会据此
    回退到 M21 的 FEFO 自动推断，保证老单据不破；新分配行带完整 8 维批次信息，
    发货严格按分配记录扣减。``dn.wave_no`` 只作展示，不参与状态机。
    """
    pick_cols = {
        "batch_no": "TEXT NOT NULL DEFAULT ''",
        "batch_key": "TEXT NOT NULL DEFAULT ''",
        "internal_batch_no": "TEXT NOT NULL DEFAULT ''",
        "designated_customer_id": "INTEGER",
        "goods_property": "TEXT NOT NULL DEFAULT ''",
        "stock_status": "TEXT NOT NULL DEFAULT ''",
        "expiry_date": "TEXT NOT NULL DEFAULT ''",
        "production_date": "TEXT NOT NULL DEFAULT ''",
        "wave_no": "TEXT NOT NULL DEFAULT ''",
        "rule_id": "INTEGER",
    }
    # 注意：SQLite 的 ALTER TABLE ADD COLUMN 不允许函数型默认值
    # （DEFAULT (datetime(...)) 会报 "Cannot add a column with non-constant default"）。
    # M35 不依赖 dn_pick.created_at，留痕时间统一取 outbound_allocation_log.created_at，
    # 因此老库不补这一列；新表 CREATE TABLE 里才允许函数默认值。
    existing = {r["name"] for r in conn.execute("PRAGMA table_info(dn_pick)")}
    for name, ddl in pick_cols.items():
        if name not in existing:
            conn.execute(f"ALTER TABLE dn_pick ADD COLUMN {name} {ddl}")
    dn_cols = {r["name"] for r in conn.execute("PRAGMA table_info(dn)")}
    if "wave_no" not in dn_cols:
        conn.execute("ALTER TABLE dn ADD COLUMN wave_no TEXT NOT NULL DEFAULT ''")
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS outbound_allocation_log (
            id                      INTEGER PRIMARY KEY AUTOINCREMENT,
            wave_no                 TEXT    NOT NULL DEFAULT '',
            dn_id                   INTEGER NOT NULL,
            line_id                 INTEGER,
            product_id              INTEGER,
            location_id             INTEGER,
            batch_no                TEXT    NOT NULL DEFAULT '',
            batch_key               TEXT    NOT NULL DEFAULT '',
            designated_customer_id  INTEGER,
            goods_property          TEXT    NOT NULL DEFAULT '',
            stock_status            TEXT    NOT NULL DEFAULT '',
            expiry_date             TEXT    NOT NULL DEFAULT '',
            qty                     REAL    NOT NULL DEFAULT 0,
            action                  TEXT    NOT NULL,
            reason_code             TEXT    NOT NULL DEFAULT '',
            reason                  TEXT    NOT NULL DEFAULT '',
            rule_id                 INTEGER,
            rule_priority           INTEGER,
            strategy                TEXT    NOT NULL DEFAULT '',
            engine                  TEXT    NOT NULL DEFAULT '',
            operator                TEXT    NOT NULL DEFAULT '',
            created_at              TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
        );
        CREATE INDEX IF NOT EXISTS idx_oal_wave   ON outbound_allocation_log(wave_no);
        CREATE INDEX IF NOT EXISTS idx_oal_dn     ON outbound_allocation_log(dn_id);
        CREATE INDEX IF NOT EXISTS idx_oal_action ON outbound_allocation_log(action);
        CREATE INDEX IF NOT EXISTS idx_dnp_wave   ON dn_pick(wave_no);
        """
    )


def _migrate_m36(conn):
    """M36 出库复核：独立复核单 + 复核行快照 + 差异留痕日志。

    三张新表，不改 ``stock`` 主账粒度、不改 ``dn`` 状态机（Q18：复核独立于发货）。
    复核行快照 ``dn_pick`` 的完整 8 维批次 + ``wave_no`` / ``rule_id``，
    差异直接定位到批次 + 库位（Q17 默认最细粒度）。
    ``dn_review_diff_log`` 只留痕：不生成调整单、不写库存流水。
    """
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS dn_review (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            code            TEXT    NOT NULL UNIQUE,
            dn_id           INTEGER NOT NULL REFERENCES dn(id),
            dn_code         TEXT    NOT NULL DEFAULT '',
            owner_id        INTEGER NOT NULL REFERENCES owner(id),
            customer_id     INTEGER,
            wave_no         TEXT    NOT NULL DEFAULT '',
            status          TEXT    NOT NULL DEFAULT 'draft',
            total_lines     INTEGER NOT NULL DEFAULT 0,
            reviewed_lines  INTEGER NOT NULL DEFAULT 0,
            diff_lines      INTEGER NOT NULL DEFAULT 0,
            note            TEXT    NOT NULL DEFAULT '',
            operator        TEXT    NOT NULL DEFAULT '',
            created_at      TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
            updated_at      TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
            reviewed_at     TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_dnrev_dn     ON dn_review(dn_id);
        CREATE INDEX IF NOT EXISTS idx_dnrev_status ON dn_review(status);
        CREATE INDEX IF NOT EXISTS idx_dnrev_owner  ON dn_review(owner_id);

        CREATE TABLE IF NOT EXISTS dn_review_line (
            id                      INTEGER PRIMARY KEY AUTOINCREMENT,
            review_id               INTEGER NOT NULL REFERENCES dn_review(id),
            dn_id                   INTEGER NOT NULL,
            line_id                 INTEGER,
            pick_id                 INTEGER NOT NULL REFERENCES dn_pick(id),
            product_id              INTEGER NOT NULL,
            sku                     TEXT    NOT NULL DEFAULT '',
            product_name            TEXT    NOT NULL DEFAULT '',
            location_id             INTEGER NOT NULL,
            location_code           TEXT    NOT NULL DEFAULT '',
            batch_no                TEXT    NOT NULL DEFAULT '',
            batch_key               TEXT    NOT NULL DEFAULT '',
            internal_batch_no       TEXT    NOT NULL DEFAULT '',
            designated_customer_id  INTEGER,
            goods_property          TEXT    NOT NULL DEFAULT '',
            stock_status            TEXT    NOT NULL DEFAULT '',
            expiry_date             TEXT    NOT NULL DEFAULT '',
            production_date         TEXT    NOT NULL DEFAULT '',
            wave_no                 TEXT    NOT NULL DEFAULT '',
            rule_id                 INTEGER,
            expected_qty            REAL    NOT NULL,
            actual_qty              REAL,
            result                  TEXT,
            diff_qty                REAL    NOT NULL DEFAULT 0,
            reason_code             TEXT    NOT NULL DEFAULT '',
            note                    TEXT    NOT NULL DEFAULT '',
            operator                TEXT    NOT NULL DEFAULT '',
            reviewed_at             TEXT,
            UNIQUE(review_id, pick_id)
        );
        CREATE INDEX IF NOT EXISTS idx_dnrevm_review ON dn_review_line(review_id);
        CREATE INDEX IF NOT EXISTS idx_dnrevm_result ON dn_review_line(result);

        CREATE TABLE IF NOT EXISTS dn_review_diff_log (
            id                      INTEGER PRIMARY KEY AUTOINCREMENT,
            review_id               INTEGER NOT NULL REFERENCES dn_review(id),
            review_code             TEXT    NOT NULL DEFAULT '',
            dn_id                   INTEGER NOT NULL,
            dn_code                 TEXT    NOT NULL DEFAULT '',
            owner_id                INTEGER NOT NULL,
            line_id                 INTEGER,
            pick_id                 INTEGER,
            product_id              INTEGER,
            sku                     TEXT    NOT NULL DEFAULT '',
            product_name            TEXT    NOT NULL DEFAULT '',
            location_id             INTEGER,
            location_code           TEXT    NOT NULL DEFAULT '',
            batch_no                TEXT    NOT NULL DEFAULT '',
            batch_key               TEXT    NOT NULL DEFAULT '',
            designated_customer_id  INTEGER,
            expiry_date             TEXT    NOT NULL DEFAULT '',
            goods_property          TEXT    NOT NULL DEFAULT '',
            stock_status            TEXT    NOT NULL DEFAULT '',
            wave_no                 TEXT    NOT NULL DEFAULT '',
            expected_qty            REAL    NOT NULL DEFAULT 0,
            actual_qty              REAL    NOT NULL DEFAULT 0,
            diff_qty                REAL    NOT NULL DEFAULT 0,
            reason_code             TEXT    NOT NULL DEFAULT '',
            reason_label            TEXT    NOT NULL DEFAULT '',
            note                    TEXT    NOT NULL DEFAULT '',
            action                  TEXT    NOT NULL DEFAULT 'diff_registered',
            operator                TEXT    NOT NULL DEFAULT '',
            created_at              TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
        );
        CREATE INDEX IF NOT EXISTS idx_dnrefl_review ON dn_review_diff_log(review_id);
        CREATE INDEX IF NOT EXISTS idx_dnrefl_dn     ON dn_review_diff_log(dn_id);
        CREATE INDEX IF NOT EXISTS idx_dnrefl_owner  ON dn_review_diff_log(owner_id);
        CREATE INDEX IF NOT EXISTS idx_dnrefl_action ON dn_review_diff_log(action);
        """
    )


def _migrate_m37(conn):
    """M37 养护管理：计划 / 任务 / 留痕三表。

    计划定义养护项目（温湿度 / 外观 / 包装 / 效期 / 堆码）、周期与阈值；
    任务由到期计划生成并快照阈值；执行只写 ``care_log`` 留痕，
    **不改库存、不生成调整单、不写 stock_movement**（延续 M36 4B 精神）。
    三表均带 owner_id，按货主隔离；库位为 0 表示仓内全库位（非 NULL 简化查询）。
    """
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS care_plan (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            code            TEXT    NOT NULL UNIQUE,
            owner_id        INTEGER NOT NULL REFERENCES owner(id),
            warehouse_id    INTEGER NOT NULL DEFAULT 0,
            location_id     INTEGER NOT NULL DEFAULT 0,
            location_code   TEXT    NOT NULL DEFAULT '',
            project         TEXT    NOT NULL,
            cycle           TEXT    NOT NULL DEFAULT 'weekly',
            cycle_days      INTEGER NOT NULL DEFAULT 7,
            temp_min        REAL,
            temp_max        REAL,
            hum_min         REAL,
            hum_max         REAL,
            next_due_date   TEXT    NOT NULL,
            status          TEXT    NOT NULL DEFAULT 'active',
            note            TEXT    NOT NULL DEFAULT '',
            operator        TEXT    NOT NULL DEFAULT '',
            created_at      TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
            updated_at      TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
        );
        CREATE INDEX IF NOT EXISTS idx_carep_owner ON care_plan(owner_id);
        CREATE INDEX IF NOT EXISTS idx_carep_due   ON care_plan(next_due_date);
        CREATE INDEX IF NOT EXISTS idx_carep_stat  ON care_plan(status);

        CREATE TABLE IF NOT EXISTS care_task (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            code            TEXT    NOT NULL UNIQUE,
            plan_id         INTEGER NOT NULL REFERENCES care_plan(id),
            plan_code       TEXT    NOT NULL DEFAULT '',
            owner_id        INTEGER NOT NULL REFERENCES owner(id),
            warehouse_id    INTEGER NOT NULL DEFAULT 0,
            location_id     INTEGER NOT NULL DEFAULT 0,
            location_code   TEXT    NOT NULL DEFAULT '',
            project         TEXT    NOT NULL,
            due_date        TEXT    NOT NULL,
            temp_min        REAL,
            temp_max        REAL,
            hum_min         REAL,
            hum_max         REAL,
            status          TEXT    NOT NULL DEFAULT 'pending',
            result          TEXT,
            temperature     REAL,
            humidity        REAL,
            reason_code     TEXT    NOT NULL DEFAULT '',
            note            TEXT    NOT NULL DEFAULT '',
            operator        TEXT    NOT NULL DEFAULT '',
            executed_at     TEXT,
            handled_note    TEXT    NOT NULL DEFAULT '',
            handler         TEXT    NOT NULL DEFAULT '',
            handled_at      TEXT,
            created_at      TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
            updated_at      TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
            UNIQUE(plan_id, due_date)
        );
        CREATE INDEX IF NOT EXISTS idx_caret_owner  ON care_task(owner_id);
        CREATE INDEX IF NOT EXISTS idx_caret_stat   ON care_task(status);
        CREATE INDEX IF NOT EXISTS idx_caret_due    ON care_task(due_date);
        CREATE INDEX IF NOT EXISTS idx_caret_plan   ON care_task(plan_id);

        CREATE TABLE IF NOT EXISTS care_log (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            task_id         INTEGER NOT NULL REFERENCES care_task(id),
            task_code       TEXT    NOT NULL DEFAULT '',
            plan_id         INTEGER NOT NULL,
            plan_code       TEXT    NOT NULL DEFAULT '',
            owner_id        INTEGER NOT NULL,
            project         TEXT    NOT NULL DEFAULT '',
            due_date        TEXT    NOT NULL DEFAULT '',
            action          TEXT    NOT NULL,
            result          TEXT    NOT NULL DEFAULT '',
            temperature     REAL,
            humidity        REAL,
            reason_code     TEXT    NOT NULL DEFAULT '',
            reason_label    TEXT    NOT NULL DEFAULT '',
            note            TEXT    NOT NULL DEFAULT '',
            operator        TEXT    NOT NULL DEFAULT '',
            created_at      TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
        );
        CREATE INDEX IF NOT EXISTS idx_carel_owner  ON care_log(owner_id);
        CREATE INDEX IF NOT EXISTS idx_carel_task   ON care_log(task_id);
        CREATE INDEX IF NOT EXISTS idx_carel_action ON care_log(action);
        """
    )


def _migrate_m38(conn):
    """M38 出库单拆单/合单：留痕表 + dn 溯源列。

    拆单/合单只在**未拣货的 open 出库单**上做单据层数量重分配，
    **不动库存、不写 stock_movement、不生成调整单**；数量守恒（Σ 拆出 = 源单拆前量，
    Σ 并入 = 各源单量之和，容差 1e-9）。dn_order_log 记录每次 split/merge 的
    源单 → 目标单与逐行数量，带 owner_id 按货主隔离。
    """
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS dn_order_log (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            action           TEXT    NOT NULL,
            owner_id         INTEGER NOT NULL,
            customer_id      INTEGER,
            source_dn_ids    TEXT    NOT NULL DEFAULT '',
            source_codes     TEXT    NOT NULL DEFAULT '',
            target_dn_ids    TEXT    NOT NULL DEFAULT '',
            target_codes     TEXT    NOT NULL DEFAULT '',
            detail           TEXT    NOT NULL DEFAULT '',
            operator         TEXT    NOT NULL DEFAULT '',
            note             TEXT    NOT NULL DEFAULT '',
            created_at       TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
        );
        CREATE INDEX IF NOT EXISTS idx_dnorder_owner  ON dn_order_log(owner_id);
        CREATE INDEX IF NOT EXISTS idx_dnorder_action ON dn_order_log(action);
        CREATE INDEX IF NOT EXISTS idx_dnorder_time   ON dn_order_log(created_at);
        """
    )
    # 老库补列：dn 记录来源（split/merge）与父单，便于列表辨识与追溯。
    # 只加常量默认值的列，避免 M35 踩过的「ALTER 默认值用函数」坑。
    cols = {r[1] for r in conn.execute("PRAGMA table_info(dn)").fetchall()}
    if "origin_action" not in cols:
        conn.execute("ALTER TABLE dn ADD COLUMN origin_action TEXT NOT NULL DEFAULT ''")
    if "origin_parent_id" not in cols:
        conn.execute("ALTER TABLE dn ADD COLUMN origin_parent_id INTEGER NOT NULL DEFAULT 0")


def _migrate_m41(conn):
    """M41 打印模板配置：节点模板表 + 每节点默认模板（幂等）。

    只存模板配置，不碰业务单据；每个节点可挂多模板、只有一个 is_active。
    用户删光某节点模板后不再复活，渲染时由 print_service.default_layout() 兜底。
    """
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS print_template (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            node         TEXT    NOT NULL,
            code         TEXT    NOT NULL UNIQUE,
            name         TEXT    NOT NULL,
            version      TEXT    NOT NULL DEFAULT '1.0',
            is_active    INTEGER NOT NULL DEFAULT 0,
            layout_json  TEXT    NOT NULL DEFAULT '{}',
            field_map    TEXT    NOT NULL DEFAULT '{}',
            note         TEXT    NOT NULL DEFAULT '',
            created_at   TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
            updated_at   TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
        );
        CREATE INDEX IF NOT EXISTS idx_printt_node   ON print_template(node);
        CREATE INDEX IF NOT EXISTS idx_printt_active ON print_template(node, is_active);
        """
    )
    from print_service import seed_templates
    seed_templates(conn)


def _migrate_m31(conn):
    """M31 司机与车辆主数据：两张独立表，均按货主隔离（NULL＝全系统共享）。

    承运商关联用 carrier_id（可空），一名司机/一辆车最多挂一个承运商（Q42）；
    证照效期只存日期字段，预警由 fleet_service 只读计算，不做硬拦截（Q43）。
    """
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS driver (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            code            TEXT    NOT NULL UNIQUE,
            name            TEXT    NOT NULL,
            phone           TEXT    NOT NULL DEFAULT '',
            id_no           TEXT    NOT NULL DEFAULT '',
            license_no      TEXT    NOT NULL DEFAULT '',
            license_type    TEXT    NOT NULL DEFAULT 'C1',
            license_expiry  TEXT    NOT NULL DEFAULT '',
            carrier_id      INTEGER REFERENCES carrier(id),
            owner_id        INTEGER REFERENCES owner(id),
            status          TEXT    NOT NULL DEFAULT 'active',
            note            TEXT    NOT NULL DEFAULT '',
            created_at      TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
            updated_at      TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
        );
        CREATE INDEX IF NOT EXISTS idx_driver_carrier ON driver(carrier_id);
        CREATE INDEX IF NOT EXISTS idx_driver_owner   ON driver(owner_id);
        CREATE INDEX IF NOT EXISTS idx_driver_expiry  ON driver(license_expiry);

        CREATE TABLE IF NOT EXISTS vehicle (
            id                    INTEGER PRIMARY KEY AUTOINCREMENT,
            code                  TEXT    NOT NULL UNIQUE,
            plate_no              TEXT    NOT NULL DEFAULT '',
            vehicle_type          TEXT    NOT NULL DEFAULT '厢式货车',
            max_load_kg           REAL    NOT NULL DEFAULT 0,
            length_cm             REAL    NOT NULL DEFAULT 0,
            width_cm              REAL    NOT NULL DEFAULT 0,
            height_cm             REAL    NOT NULL DEFAULT 0,
            insurance_expiry      TEXT    NOT NULL DEFAULT '',
            transport_expiry      TEXT    NOT NULL DEFAULT '',
            carrier_id            INTEGER REFERENCES carrier(id),
            owner_id              INTEGER REFERENCES owner(id),
            status                TEXT    NOT NULL DEFAULT 'active',
            note                  TEXT    NOT NULL DEFAULT '',
            created_at            TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
            updated_at            TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
        );
        CREATE INDEX IF NOT EXISTS idx_vehicle_carrier ON vehicle(carrier_id);
        CREATE INDEX IF NOT EXISTS idx_vehicle_owner   ON vehicle(owner_id);
        CREATE INDEX IF NOT EXISTS idx_vehicle_plate   ON vehicle(plate_no);
        """
    )


def _migrate_m32(conn):
    """M32 产品类型字典：独立主数据 + 货品改引用 + 老数据回填。

    `product.product_type` 文本列继续存在，但语义升级为「引用 product_type.code」。
    回填时**老文本原样当 code**，货品上的引用值一个字符都不改，
    因此历史盘点方案维度、报表分组继续匹配（Q47）。
    层级最多两级，父级不能再挂父级（Q46）；删除仍被引用则拒绝（Q48）。
    """
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS product_type (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            code        TEXT    NOT NULL UNIQUE,
            name        TEXT    NOT NULL,
            parent_id   INTEGER REFERENCES product_type(id),
            sort_no     INTEGER NOT NULL DEFAULT 0,
            status      TEXT    NOT NULL DEFAULT 'active',
            owner_id    INTEGER REFERENCES owner(id),
            note        TEXT    NOT NULL DEFAULT '',
            created_at  TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
            updated_at  TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
        );
        CREATE INDEX IF NOT EXISTS idx_product_type_parent ON product_type(parent_id);
        CREATE INDEX IF NOT EXISTS idx_product_type_owner  ON product_type(owner_id);
        CREATE INDEX IF NOT EXISTS idx_product_type_sort   ON product_type(sort_no);
        CREATE INDEX IF NOT EXISTS idx_product_ref         ON product(product_type);
        """
    )
    # 种子类型：策略包式不复活 —— 用户删掉的行重启不回来
    for code, name, sort_no in C.PT_SEED_TYPES:
        conn.execute(
            "INSERT OR IGNORE INTO product_type (code, name, parent_id, sort_no,"
            " status, owner_id, note) VALUES (?, ?, NULL, ?, ?, NULL, ?)",
            (code, name, sort_no, C.PT_STATUS_ACTIVE, "M32 预置类型"),
        )    # 老数据回填：货品上的历史自由文本 → 字典行（老文本即 code，取值不变）
    import product_type_service as PTS
    PTS.backfill_from_products(conn)
    conn.commit()


def _migrate_m33(conn):
    """M33 序列号台账：序列号档案 + 收发绑定流水两张表。

    台账**独立于库存主账**：序列号不参与 ``stock.qty`` 计算、不写
    ``stock_movement``，只在自己的流水表里留痕（Q52）。
    不改动 ASN / DN 收货发货主流程，M33 只做手工台账 + 只读关联（Q51）。
    """
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS serial_no (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            serial_no   TEXT    NOT NULL UNIQUE,
            product_id  INTEGER NOT NULL REFERENCES product(id),
            batch_no    TEXT    NOT NULL DEFAULT '',
            owner_id    INTEGER REFERENCES owner(id),
            status      TEXT    NOT NULL DEFAULT 'in_stock',
            location_id INTEGER REFERENCES location(id),
            in_date     TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
            out_date    TEXT    NOT NULL DEFAULT '',
            note        TEXT    NOT NULL DEFAULT '',
            created_at  TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
            updated_at  TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
        );
        CREATE INDEX IF NOT EXISTS idx_serial_product  ON serial_no(product_id);
        CREATE INDEX IF NOT EXISTS idx_serial_owner    ON serial_no(owner_id);
        CREATE INDEX IF NOT EXISTS idx_serial_status   ON serial_no(status);
        CREATE INDEX IF NOT EXISTS idx_serial_batch    ON serial_no(batch_no);

        CREATE TABLE IF NOT EXISTS serial_transaction (
            id               INTEGER PRIMARY KEY AUTOINCREMENT,
            serial_id        INTEGER NOT NULL REFERENCES serial_no(id),
            action           TEXT    NOT NULL,
            from_status      TEXT    NOT NULL DEFAULT '',
            to_status        TEXT    NOT NULL DEFAULT '',
            ref_type         TEXT    NOT NULL DEFAULT 'manual',
            ref_id           INTEGER,
            from_location_id INTEGER,
            to_location_id   INTEGER,
            operator         TEXT    NOT NULL DEFAULT '',
            note             TEXT    NOT NULL DEFAULT '',
            occurred_at      TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
        );
        CREATE INDEX IF NOT EXISTS idx_serial_txn_serial ON serial_transaction(serial_id);
        CREATE INDEX IF NOT EXISTS idx_serial_txn_time   ON serial_transaction(occurred_at);
        """
    )


def _migrate_abc(conn):
    """ABC 分类：给货品加 ``abc_class`` 列（补齐规则条件组里那一维的数据源）。

    列本身在货品表上；分类值由 ``abc_service.apply()`` 按近 N 天出库金额累计占比写入。
    这里只负责加列与索引：老库幂等补列、存量行留空（表示「未分类 / 不限」）。
    """
    cols = {r["name"] for r in conn.execute("PRAGMA table_info(product)")}
    if "abc_class" not in cols:
        conn.execute(
            "ALTER TABLE product ADD COLUMN abc_class TEXT NOT NULL DEFAULT ''")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_product_abc ON product(abc_class)")


def _migrate_m34(conn):
    """M34 货位组主数据：独立表替代 ``location.location_group`` 文本字段。

    ``location`` 表结构不变；分组文本继续存在，但语义升级为「引用 code」。
    回填时**老文本原样当 code**，库位取值一个字符都不改（Q55）。
    盘点维度改为「优先真实货位组，为空回落 zone 文本」，老方案继续命中（Q56）。
    """
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS location_group (
            id                INTEGER PRIMARY KEY AUTOINCREMENT,
            code              TEXT    NOT NULL UNIQUE,
            name              TEXT    NOT NULL,
            warehouse_id      INTEGER REFERENCES warehouse(id),
            zone_id           INTEGER REFERENCES zone(id),
            pick_seq          INTEGER NOT NULL DEFAULT 0,
            capacity_volume   REAL    NOT NULL DEFAULT 0,
            capacity_weight   REAL    NOT NULL DEFAULT 0,
            allow_mix_product INTEGER NOT NULL DEFAULT 0,
            allow_mix_batch   INTEGER NOT NULL DEFAULT 0,
            allow_mix_owner   INTEGER NOT NULL DEFAULT 0,
            status            TEXT    NOT NULL DEFAULT 'active',
            note              TEXT    NOT NULL DEFAULT '',
            created_at        TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
            updated_at        TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
        );
        CREATE INDEX IF NOT EXISTS idx_loc_group_wh   ON location_group(warehouse_id);
        CREATE INDEX IF NOT EXISTS idx_loc_group_zone ON location_group(zone_id);
        CREATE INDEX IF NOT EXISTS idx_loc_group_seq  ON location_group(pick_seq);
        CREATE INDEX IF NOT EXISTS idx_loc_ref        ON location(location_group);
        """
    )
    import location_group_service as LGS
    LGS.backfill_from_locations(conn)
    conn.commit()


def init_db(path=None):
    """初始化数据库：建表与列迁移（幂等，可重复执行）。

    ``path`` 为空时初始化中央库；按仓独立库时由 ``ensure_business_db(path)`` 传入，
    保证每个业务库拥有一套完整表结构（外键与前端下拉在分库模式下同样可用）。
    """
    conn = sqlite3.connect(path or DB_PATH)
    try:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS owner (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                code        TEXT    NOT NULL UNIQUE,
                name        TEXT    NOT NULL,
                contact     TEXT    NOT NULL DEFAULT '',
                phone       TEXT    NOT NULL DEFAULT '',
                email       TEXT    NOT NULL DEFAULT '',
                address     TEXT    NOT NULL DEFAULT '',
                start_date  TEXT    NOT NULL DEFAULT '',
                end_date    TEXT    NOT NULL DEFAULT '',
                status      TEXT    NOT NULL DEFAULT 'active',
                note        TEXT    NOT NULL DEFAULT '',
                created_at  TEXT    NOT NULL DEFAULT (datetime('now', 'localtime')),
                updated_at  TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
            );
            CREATE INDEX IF NOT EXISTS idx_owner_status ON owner(status);
            CREATE TABLE IF NOT EXISTS product (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                sku             TEXT    NOT NULL UNIQUE,
                name            TEXT    NOT NULL,
                category        TEXT    NOT NULL DEFAULT '未分类',
                unit            TEXT    NOT NULL DEFAULT '件',
                barcode         TEXT    NOT NULL DEFAULT '',
                brand           TEXT    NOT NULL DEFAULT '',
                spec            TEXT    NOT NULL DEFAULT '',
                weight_kg       REAL    NOT NULL DEFAULT 0,
                length_cm       REAL    NOT NULL DEFAULT 0,
                width_cm        REAL    NOT NULL DEFAULT 0,
                height_cm       REAL    NOT NULL DEFAULT 0,
                volume          REAL    NOT NULL DEFAULT 0,
                shelf_life_days INTEGER NOT NULL DEFAULT 0,
                purchase_price  REAL    NOT NULL DEFAULT 0,
                sale_price      REAL    NOT NULL DEFAULT 0,
                stock_qty       REAL    NOT NULL DEFAULT 0,
                min_stock       REAL    NOT NULL DEFAULT 0,
                status          TEXT    NOT NULL DEFAULT 'active',
                note            TEXT    NOT NULL DEFAULT '',
                created_at      TEXT    NOT NULL DEFAULT (datetime('now', 'localtime')),
                updated_at      TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
            );
            CREATE INDEX IF NOT EXISTS idx_product_category ON product(category);
            CREATE INDEX IF NOT EXISTS idx_product_status   ON product(status);
            CREATE TABLE IF NOT EXISTS location (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                code        TEXT    NOT NULL UNIQUE,
                name        TEXT    NOT NULL,
                zone        TEXT    NOT NULL DEFAULT '默认区',
                loc_type    TEXT    NOT NULL DEFAULT 'storage',
                capacity    REAL    NOT NULL DEFAULT 0,
                aisle       TEXT    NOT NULL DEFAULT '',
                bay         TEXT    NOT NULL DEFAULT '',
                level       TEXT    NOT NULL DEFAULT '',
                barcode     TEXT    NOT NULL DEFAULT '',
                status      TEXT    NOT NULL DEFAULT 'active',
                note        TEXT    NOT NULL DEFAULT '',
                created_at  TEXT    NOT NULL DEFAULT (datetime('now', 'localtime')),
                updated_at  TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
            );
            CREATE INDEX IF NOT EXISTS idx_location_zone  ON location(zone);
            CREATE INDEX IF NOT EXISTS idx_location_type  ON location(loc_type);
            CREATE INDEX IF NOT EXISTS idx_location_status ON location(status);
            -- 库存账（按 货主×物料×库位 唯一）：M3 建表供库位删除保护使用，
            -- M4 收货上架开始写入，M6 提供库存账查询
            CREATE TABLE IF NOT EXISTS stock (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                owner_id      INTEGER NOT NULL REFERENCES owner(id),
                product_id    INTEGER NOT NULL REFERENCES product(id),
                location_id   INTEGER NOT NULL REFERENCES location(id),
                qty           REAL    NOT NULL DEFAULT 0,
                allocated_qty REAL    NOT NULL DEFAULT 0,
                updated_at    TEXT    NOT NULL DEFAULT (datetime('now', 'localtime')),
                UNIQUE(owner_id, product_id, location_id)
            );
            CREATE INDEX IF NOT EXISTS idx_stock_location ON stock(location_id);
            """
        )
        # M16 供应商主数据（收货单的上游来源，归属货主，多货主隔离）
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS supplier (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                code        TEXT    NOT NULL UNIQUE,
                name        TEXT    NOT NULL,
                owner_id    INTEGER NOT NULL REFERENCES owner(id),
                contact     TEXT    NOT NULL DEFAULT '',
                phone       TEXT    NOT NULL DEFAULT '',
                address     TEXT    NOT NULL DEFAULT '',
                status      TEXT    NOT NULL DEFAULT 'active',
                note        TEXT    NOT NULL DEFAULT '',
                created_at  TEXT    NOT NULL DEFAULT (datetime('now', 'localtime')),
                updated_at  TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
            );
            CREATE INDEX IF NOT EXISTS idx_supplier_owner  ON supplier(owner_id);
            CREATE INDEX IF NOT EXISTS idx_supplier_status ON supplier(status);
            """
        )
        # M16 仓库主数据（多仓库支持；仓库为运营方资产，全系统共享，不绑定货主）
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS warehouse (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                code        TEXT    NOT NULL UNIQUE,
                name        TEXT    NOT NULL,
                address     TEXT    NOT NULL DEFAULT '',
                contact     TEXT    NOT NULL DEFAULT '',
                phone       TEXT    NOT NULL DEFAULT '',
                db_path     TEXT    NOT NULL DEFAULT '',
                status      TEXT    NOT NULL DEFAULT 'active',
                note        TEXT    NOT NULL DEFAULT '',
                created_at  TEXT    NOT NULL DEFAULT (datetime('now', 'localtime')),
                updated_at  TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
            );
            CREATE INDEX IF NOT EXISTS idx_warehouse_status ON warehouse(status);
            """
        )
        # 列迁移：product.owner_id（M2 多货主；NULL 表示自营/未指定货主）
        cols = {r[1] for r in conn.execute("PRAGMA table_info(product)")}
        if "owner_id" not in cols:
            conn.execute(
                "ALTER TABLE product ADD COLUMN owner_id INTEGER"
                " REFERENCES owner(id)"
            )
            conn.execute("CREATE INDEX IF NOT EXISTS idx_product_owner ON product(owner_id)")
        # 列迁移：stock.allocated_qty（M4，参考 Sentry WMS 三数量字段设计；
        # 旧库的 stock 表无此列，新库 DDL 已自带则跳过）
        tables = {r[0] for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        )}
        if "stock" in tables:
            stock_cols = {r[1] for r in conn.execute("PRAGMA table_info(stock)")}
            if "allocated_qty" not in stock_cols:
                conn.execute(
                    "ALTER TABLE stock ADD COLUMN allocated_qty REAL NOT NULL DEFAULT 0"
                )
        # M4 收货单：ASN 主表 + 行表 + 库存动作流水
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS asn (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                code            TEXT    NOT NULL UNIQUE,
                owner_id        INTEGER NOT NULL REFERENCES owner(id),
                doc_type        TEXT    NOT NULL DEFAULT '采购',
                external_no     TEXT    NOT NULL DEFAULT '',
                order_source    TEXT    NOT NULL DEFAULT '',
                is_virtual      INTEGER NOT NULL DEFAULT 0,
                is_direct       INTEGER NOT NULL DEFAULT 0,
                is_cold_chain   INTEGER NOT NULL DEFAULT 0,
                is_hazard       INTEGER NOT NULL DEFAULT 0,
                external_doc_type TEXT  NOT NULL DEFAULT '',
                source_warehouse INTEGER REFERENCES warehouse(id),
                supplier_id     INTEGER REFERENCES supplier(id),
                customer_name   TEXT    NOT NULL DEFAULT '',
                customer_id     INTEGER REFERENCES customer(id),
                customer_contact TEXT   NOT NULL DEFAULT '',
                customer_phone  TEXT    NOT NULL DEFAULT '',
                customer_address TEXT   NOT NULL DEFAULT '',
                carrier_name    TEXT    NOT NULL DEFAULT '',
                supplier_name   TEXT    NOT NULL DEFAULT '',
                supplier_contact TEXT   NOT NULL DEFAULT '',
                supplier_phone  TEXT    NOT NULL DEFAULT '',
                supplier_address TEXT   NOT NULL DEFAULT '',
                total_qty       REAL    NOT NULL DEFAULT 0,
                category_count  INTEGER NOT NULL DEFAULT 0,
                status          TEXT    NOT NULL DEFAULT 'open',
                extra1          TEXT    NOT NULL DEFAULT '',
                extra2          TEXT    NOT NULL DEFAULT '',
                extra3          TEXT    NOT NULL DEFAULT '',
                note            TEXT    NOT NULL DEFAULT '',
                external_batch_no TEXT  NOT NULL DEFAULT '',
                created_at      TEXT    NOT NULL DEFAULT (datetime('now', 'localtime')),
                updated_at      TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
            );
            CREATE INDEX IF NOT EXISTS idx_asn_owner  ON asn(owner_id);
            CREATE INDEX IF NOT EXISTS idx_asn_status ON asn(status);
            CREATE TABLE IF NOT EXISTS asn_line (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                asn_id       INTEGER NOT NULL REFERENCES asn(id),
                product_id   INTEGER NOT NULL REFERENCES product(id),
                expected_qty REAL    NOT NULL,
                received_qty REAL    NOT NULL DEFAULT 0,
                putaway_qty  REAL    NOT NULL DEFAULT 0,
                extra        TEXT    NOT NULL DEFAULT '',
                UNIQUE(asn_id, product_id)
            );
            CREATE INDEX IF NOT EXISTS idx_asn_line_asn ON asn_line(asn_id);
            CREATE TABLE IF NOT EXISTS stock_movement (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                owner_id    INTEGER NOT NULL REFERENCES owner(id),
                product_id  INTEGER NOT NULL REFERENCES product(id),
                location_id INTEGER NOT NULL REFERENCES location(id),
                qty_delta   REAL    NOT NULL,
                ref_type    TEXT    NOT NULL,
                ref_id      INTEGER,
                note        TEXT    NOT NULL DEFAULT '',
                created_at  TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
            );
            CREATE INDEX IF NOT EXISTS idx_movement_owner ON stock_movement(owner_id);
            CREATE INDEX IF NOT EXISTS idx_movement_ref   ON stock_movement(ref_type, ref_id);
            -- M7 客户主数据：客户归属货主（多货主下客户是货主的客户），出库单关联客户
            CREATE TABLE IF NOT EXISTS customer (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                code        TEXT    NOT NULL UNIQUE,
                name        TEXT    NOT NULL,
                owner_id    INTEGER NOT NULL REFERENCES owner(id),
                contact     TEXT    NOT NULL DEFAULT '',
                phone       TEXT    NOT NULL DEFAULT '',
                address     TEXT    NOT NULL DEFAULT '',
                email       TEXT    NOT NULL DEFAULT '',
                level       TEXT    NOT NULL DEFAULT '普通',
                region      TEXT    NOT NULL DEFAULT '',
                status      TEXT    NOT NULL DEFAULT 'active',
                note        TEXT    NOT NULL DEFAULT '',
                created_at  TEXT    NOT NULL DEFAULT (datetime('now', 'localtime')),
                updated_at  TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
            );
            CREATE INDEX IF NOT EXISTS idx_customer_owner  ON customer(owner_id);
            CREATE INDEX IF NOT EXISTS idx_customer_status ON customer(status);
            -- M5 出库单：主表 + 行表 + 拣货明细（拣货在哪些库位各分配多少，发货按此扣减）
            CREATE TABLE IF NOT EXISTS dn (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                code            TEXT    NOT NULL UNIQUE,
                owner_id        INTEGER NOT NULL REFERENCES owner(id),
                customer_id     INTEGER REFERENCES customer(id),
                doc_type        TEXT    NOT NULL DEFAULT '销售',
                external_no     TEXT    NOT NULL DEFAULT '',
                order_source    TEXT    NOT NULL DEFAULT '',
                is_virtual      INTEGER NOT NULL DEFAULT 0,
                is_direct       INTEGER NOT NULL DEFAULT 0,
                is_cold_chain   INTEGER NOT NULL DEFAULT 0,
                is_hazard       INTEGER NOT NULL DEFAULT 0,
                external_doc_type TEXT  NOT NULL DEFAULT '',
                source_warehouse INTEGER REFERENCES warehouse(id),
                carrier_name    TEXT    NOT NULL DEFAULT '',
                total_qty       REAL    NOT NULL DEFAULT 0,
                category_count  INTEGER NOT NULL DEFAULT 0,
                status          TEXT    NOT NULL DEFAULT 'open',
                extra1          TEXT    NOT NULL DEFAULT '',
                extra2          TEXT    NOT NULL DEFAULT '',
                extra3          TEXT    NOT NULL DEFAULT '',
                note            TEXT    NOT NULL DEFAULT '',
                created_at      TEXT    NOT NULL DEFAULT (datetime('now', 'localtime')),
                updated_at      TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
            );
            CREATE INDEX IF NOT EXISTS idx_dn_owner  ON dn(owner_id);
            CREATE INDEX IF NOT EXISTS idx_dn_status ON dn(status);
            CREATE TABLE IF NOT EXISTS dn_line (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                dn_id        INTEGER NOT NULL REFERENCES dn(id),
                product_id   INTEGER NOT NULL REFERENCES product(id),
                ordered_qty  REAL    NOT NULL,
                picked_qty   REAL    NOT NULL DEFAULT 0,
                UNIQUE(dn_id, product_id)
            );
            CREATE INDEX IF NOT EXISTS idx_dn_line_dn ON dn_line(dn_id);
            CREATE TABLE IF NOT EXISTS dn_pick (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                dn_id       INTEGER NOT NULL REFERENCES dn(id),
                line_id     INTEGER NOT NULL REFERENCES dn_line(id),
                location_id INTEGER NOT NULL REFERENCES location(id),
                qty         REAL    NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_dn_pick_dn ON dn_pick(dn_id);
            """
        )
        # M7 客户主数据：customer 表（新库 DDL 已带则跳过）+ dn.customer_id 列迁移
        if "customer" not in tables:
            conn.executescript(
                """                   CREATE TABLE IF NOT EXISTS customer (
                       id          INTEGER PRIMARY KEY AUTOINCREMENT,
                       code        TEXT    NOT NULL UNIQUE,
                       name        TEXT    NOT NULL,
                       owner_id    INTEGER NOT NULL REFERENCES owner(id),
                       contact     TEXT    NOT NULL DEFAULT '',
                       phone       TEXT    NOT NULL DEFAULT '',
                       address     TEXT    NOT NULL DEFAULT '',
                       email       TEXT    NOT NULL DEFAULT '',
                       level       TEXT    NOT NULL DEFAULT '普通',
                       region      TEXT    NOT NULL DEFAULT '',
                       status      TEXT    NOT NULL DEFAULT 'active',
                       note        TEXT    NOT NULL DEFAULT '',
                       created_at  TEXT    NOT NULL DEFAULT (datetime('now', 'localtime')),
                       updated_at  TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
                   );
                   CREATE INDEX IF NOT EXISTS idx_customer_owner  ON customer(owner_id);
                   CREATE INDEX IF NOT EXISTS idx_customer_status ON customer(status);"""
            )
        if "dn" in tables:
            dn_cols = {r[1] for r in conn.execute("PRAGMA table_info(dn)")}
            if "customer_id" not in dn_cols:
                conn.execute(
                    "ALTER TABLE dn ADD COLUMN customer_id INTEGER REFERENCES customer(id)"
                )
        # M16 单据字段增强：ASN/DN 新增单据类型/外部单号/来源仓库/供应商/承运商/自定义字段/汇总字段
        if "asn" in tables:
            asn_cols = {r[1] for r in conn.execute("PRAGMA table_info(asn)")}
            for col, ddl in (
                ("doc_type", "ALTER TABLE asn ADD COLUMN doc_type TEXT NOT NULL DEFAULT '采购'"),
                ("external_no", "ALTER TABLE asn ADD COLUMN external_no TEXT NOT NULL DEFAULT ''"),
                ("order_source", "ALTER TABLE asn ADD COLUMN order_source TEXT NOT NULL DEFAULT ''"),
                ("source_warehouse", "ALTER TABLE asn ADD COLUMN source_warehouse INTEGER REFERENCES warehouse(id)"),
                ("supplier_id", "ALTER TABLE asn ADD COLUMN supplier_id INTEGER REFERENCES supplier(id)"),
                ("customer_name", "ALTER TABLE asn ADD COLUMN customer_name TEXT NOT NULL DEFAULT ''"),
                ("carrier_name", "ALTER TABLE asn ADD COLUMN carrier_name TEXT NOT NULL DEFAULT ''"),
                ("supplier_name", "ALTER TABLE asn ADD COLUMN supplier_name TEXT NOT NULL DEFAULT ''"),
                ("supplier_contact", "ALTER TABLE asn ADD COLUMN supplier_contact TEXT NOT NULL DEFAULT ''"),
                ("supplier_phone", "ALTER TABLE asn ADD COLUMN supplier_phone TEXT NOT NULL DEFAULT ''"),
                ("supplier_address", "ALTER TABLE asn ADD COLUMN supplier_address TEXT NOT NULL DEFAULT ''"),
                ("total_qty", "ALTER TABLE asn ADD COLUMN total_qty REAL NOT NULL DEFAULT 0"),
                ("category_count", "ALTER TABLE asn ADD COLUMN category_count INTEGER NOT NULL DEFAULT 0"),
                ("extra1", "ALTER TABLE asn ADD COLUMN extra1 TEXT NOT NULL DEFAULT ''"),
                ("extra2", "ALTER TABLE asn ADD COLUMN extra2 TEXT NOT NULL DEFAULT ''"),
                ("extra3", "ALTER TABLE asn ADD COLUMN extra3 TEXT NOT NULL DEFAULT ''"),
                # 收货单往来单位联系方式（可在下单时覆盖主数据快照）
                ("customer_id", "ALTER TABLE asn ADD COLUMN customer_id INTEGER REFERENCES customer(id)"),
                ("customer_contact", "ALTER TABLE asn ADD COLUMN customer_contact TEXT NOT NULL DEFAULT ''"),
                ("customer_phone", "ALTER TABLE asn ADD COLUMN customer_phone TEXT NOT NULL DEFAULT ''"),
                ("customer_address", "ALTER TABLE asn ADD COLUMN customer_address TEXT NOT NULL DEFAULT ''"),
            ):
                if col not in asn_cols:
                    conn.execute(ddl)
        # 收货明细商品档案快照（JSON：规格/货号/批号/效期/注册证等，选商品时自动带出）
        if conn.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='asn_line'"
        ).fetchone():
            line_cols = {r[1] for r in conn.execute("PRAGMA table_info(asn_line)")}
            if "extra" not in line_cols:
                conn.execute("ALTER TABLE asn_line ADD COLUMN extra TEXT NOT NULL DEFAULT ''")
        if "dn" in tables:
            dn_cols = {r[1] for r in conn.execute("PRAGMA table_info(dn)")}
            for col, ddl in (
                ("doc_type", "ALTER TABLE dn ADD COLUMN doc_type TEXT NOT NULL DEFAULT '销售'"),
                ("external_no", "ALTER TABLE dn ADD COLUMN external_no TEXT NOT NULL DEFAULT ''"),
                ("order_source", "ALTER TABLE dn ADD COLUMN order_source TEXT NOT NULL DEFAULT ''"),
                ("source_warehouse", "ALTER TABLE dn ADD COLUMN source_warehouse INTEGER REFERENCES warehouse(id)"),
                ("carrier_name", "ALTER TABLE dn ADD COLUMN carrier_name TEXT NOT NULL DEFAULT ''"),
                ("total_qty", "ALTER TABLE dn ADD COLUMN total_qty REAL NOT NULL DEFAULT 0"),
                ("category_count", "ALTER TABLE dn ADD COLUMN category_count INTEGER NOT NULL DEFAULT 0"),
                ("extra1", "ALTER TABLE dn ADD COLUMN extra1 TEXT NOT NULL DEFAULT ''"),
                ("extra2", "ALTER TABLE dn ADD COLUMN extra2 TEXT NOT NULL DEFAULT ''"),
                ("extra3", "ALTER TABLE dn ADD COLUMN extra3 TEXT NOT NULL DEFAULT ''"),
            ):
                if col not in dn_cols:
                    conn.execute(ddl)
        # M8 主数据字段增强：电商场景补充字段（旧库 ALTER 迁移；新库 DDL 已带则跳过）
        if "owner" in tables:
            owner_cols = {r[1] for r in conn.execute("PRAGMA table_info(owner)")}
            for col, ddl in (
                ("email", "ALTER TABLE owner ADD COLUMN email TEXT NOT NULL DEFAULT ''"),
                ("address", "ALTER TABLE owner ADD COLUMN address TEXT NOT NULL DEFAULT ''"),
            ):
                if col not in owner_cols:
                    conn.execute(ddl)
        # M11 货主主数据深化：省市区/备用地址/授权仓库/经营范围/备用字段 + 证照子表
        if "owner" in tables:
            owner_cols = {r[1] for r in conn.execute("PRAGMA table_info(owner)")}
            for col, ddl in (
                ("province", "ALTER TABLE owner ADD COLUMN province TEXT NOT NULL DEFAULT ''"),
                ("city", "ALTER TABLE owner ADD COLUMN city TEXT NOT NULL DEFAULT ''"),
                ("district", "ALTER TABLE owner ADD COLUMN district TEXT NOT NULL DEFAULT ''"),
                ("backup_address", "ALTER TABLE owner ADD COLUMN backup_address TEXT NOT NULL DEFAULT ''"),
                ("authorized_warehouse", "ALTER TABLE owner ADD COLUMN authorized_warehouse TEXT NOT NULL DEFAULT ''"),
                ("business_scope", "ALTER TABLE owner ADD COLUMN business_scope TEXT NOT NULL DEFAULT ''"),
                ("start_date", "ALTER TABLE owner ADD COLUMN start_date TEXT NOT NULL DEFAULT ''"),
                ("end_date", "ALTER TABLE owner ADD COLUMN end_date TEXT NOT NULL DEFAULT ''"),
                ("extra1", "ALTER TABLE owner ADD COLUMN extra1 TEXT NOT NULL DEFAULT ''"),
                ("extra2", "ALTER TABLE owner ADD COLUMN extra2 TEXT NOT NULL DEFAULT ''"),
            ):
                if col not in owner_cols:
                    conn.execute(ddl)
        # M11 货主证照子表（营业执照/医疗器械经营许可等，可多证）
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS owner_cert (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                owner_id      INTEGER NOT NULL REFERENCES owner(id),
                cert_type     TEXT    NOT NULL DEFAULT '',
                cert_no       TEXT    NOT NULL DEFAULT '',
                issuer        TEXT    NOT NULL DEFAULT '',
                valid_from    TEXT    NOT NULL DEFAULT '',
                valid_to      TEXT    NOT NULL DEFAULT '',
                note          TEXT    NOT NULL DEFAULT '',
                created_at    TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
            );
            CREATE INDEX IF NOT EXISTS idx_owner_cert_owner ON owner_cert(owner_id);
            """
        )
        # 注意：customer 表在本函数稍早才创建，不能用函数开头的 tables 快照判断，
        # 否则全新库会跳过列迁移导致 /api/customers 插入缺列（实测新库 bug）。
        if conn.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='customer'"
        ).fetchone():
            cust_cols = {r[1] for r in conn.execute("PRAGMA table_info(customer)")}
            for col, ddl in (
                ("email", "ALTER TABLE customer ADD COLUMN email TEXT NOT NULL DEFAULT ''"),
                ("level", "ALTER TABLE customer ADD COLUMN level TEXT NOT NULL DEFAULT '普通'"),
                ("region", "ALTER TABLE customer ADD COLUMN region TEXT NOT NULL DEFAULT ''"),
            ):
                if col not in cust_cols:
                    conn.execute(ddl)
        # M12 客户主数据深化：省市区 + 详细地址 + 经营范围（同样用实时表判断）
        if conn.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='customer'"
        ).fetchone():
            cust_cols = {r[1] for r in conn.execute("PRAGMA table_info(customer)")}
            for col, ddl in (
                ("province", "ALTER TABLE customer ADD COLUMN province TEXT NOT NULL DEFAULT ''"),
                ("city", "ALTER TABLE customer ADD COLUMN city TEXT NOT NULL DEFAULT ''"),
                ("district", "ALTER TABLE customer ADD COLUMN district TEXT NOT NULL DEFAULT ''"),
                ("detail_address", "ALTER TABLE customer ADD COLUMN detail_address TEXT NOT NULL DEFAULT ''"),
                ("business_scope", "ALTER TABLE customer ADD COLUMN business_scope TEXT NOT NULL DEFAULT ''"),
            ):
                if col not in cust_cols:
                    conn.execute(ddl)
        if "product" in tables:
            prod_cols = {r[1] for r in conn.execute("PRAGMA table_info(product)")}
            for col, ddl in (
                ("barcode", "ALTER TABLE product ADD COLUMN barcode TEXT NOT NULL DEFAULT ''"),
                ("brand", "ALTER TABLE product ADD COLUMN brand TEXT NOT NULL DEFAULT ''"),
                ("spec", "ALTER TABLE product ADD COLUMN spec TEXT NOT NULL DEFAULT ''"),
                ("weight_kg", "ALTER TABLE product ADD COLUMN weight_kg REAL NOT NULL DEFAULT 0"),
                ("length_cm", "ALTER TABLE product ADD COLUMN length_cm REAL NOT NULL DEFAULT 0"),
                ("width_cm", "ALTER TABLE product ADD COLUMN width_cm REAL NOT NULL DEFAULT 0"),
                ("height_cm", "ALTER TABLE product ADD COLUMN height_cm REAL NOT NULL DEFAULT 0"),
                ("shelf_life_days", "ALTER TABLE product ADD COLUMN shelf_life_days INTEGER NOT NULL DEFAULT 0"),
            ):
                if col not in prod_cols:
                    conn.execute(ddl)
        # M10 物料主数据深化：电商/医药级字段（旧库 ALTER 迁移；新库 DDL 已带则跳过）
        if "product" in tables:
            prod_cols = {r[1] for r in conn.execute("PRAGMA table_info(product)")}
            for col, ddl in (
                ("article_no", "ALTER TABLE product ADD COLUMN article_no TEXT NOT NULL DEFAULT ''"),
                ("category_l1", "ALTER TABLE product ADD COLUMN category_l1 TEXT NOT NULL DEFAULT ''"),
                ("category_l2", "ALTER TABLE product ADD COLUMN category_l2 TEXT NOT NULL DEFAULT ''"),
                ("category_l3", "ALTER TABLE product ADD COLUMN category_l3 TEXT NOT NULL DEFAULT ''"),
                ("category_l4", "ALTER TABLE product ADD COLUMN category_l4 TEXT NOT NULL DEFAULT ''"),
                ("product_type", "ALTER TABLE product ADD COLUMN product_type TEXT NOT NULL DEFAULT ''"),
                ("origin", "ALTER TABLE product ADD COLUMN origin TEXT NOT NULL DEFAULT ''"),
                ("business_scope", "ALTER TABLE product ADD COLUMN business_scope TEXT NOT NULL DEFAULT ''"),
                ("reg_cert_no", "ALTER TABLE product ADD COLUMN reg_cert_no TEXT NOT NULL DEFAULT ''"),
                ("registrant", "ALTER TABLE product ADD COLUMN registrant TEXT NOT NULL DEFAULT ''"),
                ("mfg_enterprise", "ALTER TABLE product ADD COLUMN mfg_enterprise TEXT NOT NULL DEFAULT ''"),
                ("mfg_license", "ALTER TABLE product ADD COLUMN mfg_license TEXT NOT NULL DEFAULT ''"),
                ("external_code", "ALTER TABLE product ADD COLUMN external_code TEXT NOT NULL DEFAULT ''"),
                ("main_category", "ALTER TABLE product ADD COLUMN main_category TEXT NOT NULL DEFAULT ''"),
                ("temp_range", "ALTER TABLE product ADD COLUMN temp_range TEXT NOT NULL DEFAULT ''"),
                ("humidity_range", "ALTER TABLE product ADD COLUMN humidity_range TEXT NOT NULL DEFAULT ''"),
                ("hazard_type", "ALTER TABLE product ADD COLUMN hazard_type TEXT NOT NULL DEFAULT ''"),
                ("is_serial", "ALTER TABLE product ADD COLUMN is_serial INTEGER NOT NULL DEFAULT 0"),
                ("is_shelf_control", "ALTER TABLE product ADD COLUMN is_shelf_control INTEGER NOT NULL DEFAULT 0"),
                ("extra1", "ALTER TABLE product ADD COLUMN extra1 TEXT NOT NULL DEFAULT ''"),
                ("extra2", "ALTER TABLE product ADD COLUMN extra2 TEXT NOT NULL DEFAULT ''"),
                ("extra3", "ALTER TABLE product ADD COLUMN extra3 TEXT NOT NULL DEFAULT ''"),
            ):
                if col not in prod_cols:
                    conn.execute(ddl)
        # M15 物料体积（可手填；未填则按长宽高自动换算 cm³）
        if "product" in tables:
            if "volume" not in {r[1] for r in conn.execute("PRAGMA table_info(product)")}:
                conn.execute("ALTER TABLE product ADD COLUMN volume REAL NOT NULL DEFAULT 0")
        # M10 物料条码/包装子表（多条码扫码、多层级包装规格；新库 CREATE IF NOT EXISTS 自带，旧库执行一次）
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS product_barcode (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                product_id  INTEGER NOT NULL REFERENCES product(id),
                barcode     TEXT    NOT NULL,
                is_primary  INTEGER NOT NULL DEFAULT 0,
                created_at  TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
            );
            CREATE INDEX IF NOT EXISTS idx_pb_product ON product_barcode(product_id);
            CREATE INDEX IF NOT EXISTS idx_pb_barcode ON product_barcode(barcode);
            CREATE TABLE IF NOT EXISTS product_package (
                id               INTEGER PRIMARY KEY AUTOINCREMENT,
                product_id       INTEGER NOT NULL REFERENCES product(id),
                pkg_level        TEXT    NOT NULL DEFAULT '主箱',
                length_cm        REAL    NOT NULL DEFAULT 0,
                width_cm         REAL    NOT NULL DEFAULT 0,
                height_cm        REAL    NOT NULL DEFAULT 0,
                volume           REAL    NOT NULL DEFAULT 0,
                weight_kg        REAL    NOT NULL DEFAULT 0,
                qty_per_package  REAL    NOT NULL DEFAULT 0,
                created_at       TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
            );
            CREATE INDEX IF NOT EXISTS idx_pp_product ON product_package(product_id);
            """
        )
        if "location" in tables:
            loc_cols = {r[1] for r in conn.execute("PRAGMA table_info(location)")}
            for col, ddl in (
                ("aisle", "ALTER TABLE location ADD COLUMN aisle TEXT NOT NULL DEFAULT ''"),
                ("bay", "ALTER TABLE location ADD COLUMN bay TEXT NOT NULL DEFAULT ''"),
                ("level", "ALTER TABLE location ADD COLUMN level TEXT NOT NULL DEFAULT ''"),
                ("barcode", "ALTER TABLE location ADD COLUMN barcode TEXT NOT NULL DEFAULT ''"),
            ):
                if col not in loc_cols:
                    conn.execute(ddl)
        # M13 库位主数据深化：库位组 + 长宽高 + 体积库容（按体积计算）
        if "location" in tables:
            loc_cols = {r[1] for r in conn.execute("PRAGMA table_info(location)")}
            for col, ddl in (
                ("location_group", "ALTER TABLE location ADD COLUMN location_group TEXT NOT NULL DEFAULT ''"),
                ("length_cm", "ALTER TABLE location ADD COLUMN length_cm REAL NOT NULL DEFAULT 0"),
                ("width_cm", "ALTER TABLE location ADD COLUMN width_cm REAL NOT NULL DEFAULT 0"),
                ("height_cm", "ALTER TABLE location ADD COLUMN height_cm REAL NOT NULL DEFAULT 0"),
                ("capacity_volume", "ALTER TABLE location ADD COLUMN capacity_volume REAL NOT NULL DEFAULT 0"),
            ):
                if col not in loc_cols:
                    conn.execute(ddl)
        # M14 承运商（物流履约资源，全系统共享，独立于多货主）
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS carrier (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                code          TEXT    NOT NULL UNIQUE,
                name          TEXT    NOT NULL,
                contact       TEXT    NOT NULL DEFAULT '',
                phone         TEXT    NOT NULL DEFAULT '',
                api_code      TEXT    NOT NULL DEFAULT '',
                address       TEXT    NOT NULL DEFAULT '',
                carrier_type  TEXT    NOT NULL DEFAULT '快递',
                owner_id      INTEGER REFERENCES owner(id),
                status        TEXT    NOT NULL DEFAULT 'active',
                note          TEXT    NOT NULL DEFAULT '',
                created_at    TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
                updated_at    TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
            );
            CREATE INDEX IF NOT EXISTS idx_carrier_code   ON carrier(code);
            CREATE INDEX IF NOT EXISTS idx_carrier_type   ON carrier(carrier_type);
            CREATE INDEX IF NOT EXISTS idx_carrier_status ON carrier(status);
            """
        )
        # M16 移库单（Stock Transfer）：单据驱动库位间一减一增，同事务原子完成
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS transfer (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                code        TEXT    NOT NULL UNIQUE,
                owner_id    INTEGER NOT NULL REFERENCES owner(id),
                status      TEXT    NOT NULL DEFAULT 'open',
                note        TEXT    NOT NULL DEFAULT '',
                created_at  TEXT    NOT NULL DEFAULT (datetime('now', 'localtime')),
                updated_at  TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
            );
            CREATE INDEX IF NOT EXISTS idx_transfer_owner  ON transfer(owner_id);
            CREATE INDEX IF NOT EXISTS idx_transfer_status ON transfer(status);
            CREATE TABLE IF NOT EXISTS transfer_line (
                id               INTEGER PRIMARY KEY AUTOINCREMENT,
                transfer_id     INTEGER NOT NULL REFERENCES transfer(id),
                product_id      INTEGER NOT NULL REFERENCES product(id),
                from_location_id INTEGER NOT NULL REFERENCES location(id),
                to_location_id  INTEGER NOT NULL REFERENCES location(id),
                qty             REAL    NOT NULL,
                UNIQUE(transfer_id, product_id, from_location_id, to_location_id)
            );
            CREATE INDEX IF NOT EXISTS idx_transfer_line_transfer ON transfer_line(transfer_id);
            """
        )
        # M17 盘点单（Stocktake）：单据驱动账实核对——冻结快照 → 盲盘 → 差异调整 → 解冻
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS stocktake (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                code        TEXT    NOT NULL UNIQUE,
                owner_id    INTEGER NOT NULL REFERENCES owner(id),
                status      TEXT    NOT NULL DEFAULT 'open',
                note        TEXT    NOT NULL DEFAULT '',
                created_at  TEXT    NOT NULL DEFAULT (datetime('now', 'localtime')),
                updated_at  TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
            );
            CREATE INDEX IF NOT EXISTS idx_stocktake_owner  ON stocktake(owner_id);
            CREATE INDEX IF NOT EXISTS idx_stocktake_status ON stocktake(status);
            CREATE TABLE IF NOT EXISTS stocktake_line (
                id               INTEGER PRIMARY KEY AUTOINCREMENT,
                stocktake_id     INTEGER NOT NULL REFERENCES stocktake(id),
                owner_id         INTEGER NOT NULL REFERENCES owner(id),
                product_id       INTEGER NOT NULL REFERENCES product(id),
                location_id      INTEGER NOT NULL REFERENCES location(id),
                book_qty         REAL    NOT NULL DEFAULT 0,
                counted_qty      REAL    DEFAULT NULL,
                UNIQUE(stocktake_id, product_id, location_id)
            );
            CREATE INDEX IF NOT EXISTS idx_stocktake_line_st ON stocktake_line(stocktake_id);
            """
        )
        # M19 批次（医疗器械/GSP 口径）：批次字段配置 / 批次档案 / 每次入库唯一批次流水
        # 级联删除仅用于保持历史数据一致性；批次流水本身只能由收货单验收写入，不提供手工新增接口
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS batch_config (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                field_name    TEXT    NOT NULL UNIQUE,
                label         TEXT    NOT NULL DEFAULT '',
                input_type    TEXT    NOT NULL DEFAULT 'text',
                is_key        INTEGER NOT NULL DEFAULT 0,
                enabled       INTEGER NOT NULL DEFAULT 1,
                default_value TEXT    NOT NULL DEFAULT '',
                sort_order    INTEGER NOT NULL DEFAULT 0,
                note          TEXT    NOT NULL DEFAULT '',
                updated_at    TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
            );
            CREATE TABLE IF NOT EXISTS batch (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                code          TEXT    NOT NULL UNIQUE,
                batch_key     TEXT    NOT NULL UNIQUE,
                owner_id      INTEGER NOT NULL REFERENCES owner(id) ON DELETE CASCADE,
                product_id    INTEGER NOT NULL REFERENCES product(id) ON DELETE CASCADE,
                key_info      TEXT    NOT NULL DEFAULT '{}',
                info          TEXT    NOT NULL DEFAULT '{}',
                receipt_count INTEGER NOT NULL DEFAULT 0,
                created_at    TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
                updated_at    TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
            );
            CREATE INDEX IF NOT EXISTS idx_batch_owner   ON batch(owner_id);
            CREATE INDEX IF NOT EXISTS idx_batch_product ON batch(product_id);
            CREATE TABLE IF NOT EXISTS asn_receiving_count (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                asn_line_id INTEGER NOT NULL REFERENCES asn_line(id) ON DELETE CASCADE,
                location_id INTEGER REFERENCES location(id) ON DELETE SET NULL,
                qty REAL NOT NULL CHECK (qty > 0),
                accepted_qty REAL NOT NULL DEFAULT 0,
                cancelled_qty REAL NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
            );
            CREATE INDEX IF NOT EXISTS idx_asn_receiving_count_line
                ON asn_receiving_count(asn_line_id);
            CREATE TABLE IF NOT EXISTS batch_receipt (
                id                INTEGER PRIMARY KEY AUTOINCREMENT,
                batch_no          TEXT    NOT NULL UNIQUE,
                batch_id          INTEGER NOT NULL REFERENCES batch(id) ON DELETE CASCADE,
                internal_batch_no TEXT    NOT NULL DEFAULT '',
                internal_source   TEXT    NOT NULL DEFAULT 'first_in',
                owner_id          INTEGER NOT NULL REFERENCES owner(id) ON DELETE CASCADE,
                product_id        INTEGER NOT NULL REFERENCES product(id) ON DELETE CASCADE,
                location_id       INTEGER NOT NULL REFERENCES location(id) ON DELETE CASCADE,
                asn_id            INTEGER NOT NULL REFERENCES asn(id) ON DELETE CASCADE,
                asn_line_id       INTEGER NOT NULL REFERENCES asn_line(id) ON DELETE CASCADE,
                qty               REAL    NOT NULL,
                doc_type          TEXT    NOT NULL DEFAULT '',
                goods_property    TEXT    NOT NULL DEFAULT '',
                info              TEXT    NOT NULL DEFAULT '{}',
                designated_customer_id INTEGER,
                external_batch_no TEXT    NOT NULL DEFAULT '',
                warning           TEXT    NOT NULL DEFAULT '',
                created_at        TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
            );
            CREATE INDEX IF NOT EXISTS idx_batch_receipt_batch    ON batch_receipt(batch_id);
            CREATE INDEX IF NOT EXISTS idx_batch_receipt_asn      ON batch_receipt(asn_id);
            CREATE INDEX IF NOT EXISTS idx_batch_receipt_line     ON batch_receipt(asn_line_id);
            CREATE INDEX IF NOT EXISTS idx_batch_receipt_internal ON batch_receipt(internal_batch_no);
            """
        )
        # 批次字段配置播种（幂等，不覆盖用户已改的配置）
        from batch_fields import seed_batch_config  # noqa: E402
        _ensure_columns(conn, "batch_receipt", (
            ("receiving_count_id", "INTEGER REFERENCES asn_receiving_count(id) ON DELETE SET NULL"),
            ("operator", "TEXT NOT NULL DEFAULT ''"),
            ("stock_status", "TEXT NOT NULL DEFAULT ''"),
        ))
        seed_batch_config(conn)
        # 用户与角色（M9 基础：后续功能通过 require_permission 联动）
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS role (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                name         TEXT    NOT NULL UNIQUE,
                permissions  TEXT    NOT NULL DEFAULT '[]',
                created_at   TEXT    NOT NULL DEFAULT (datetime('now', 'localtime')),
                updated_at   TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
            );
            CREATE TABLE IF NOT EXISTS user (
                id             INTEGER PRIMARY KEY AUTOINCREMENT,
                username       TEXT    NOT NULL UNIQUE,
                password_salt  TEXT    NOT NULL DEFAULT '',
                password_hash  TEXT    NOT NULL DEFAULT '',
                role_id        INTEGER REFERENCES role(id),
                owner_id       INTEGER REFERENCES owner(id),
                warehouse_scope TEXT  NOT NULL DEFAULT 'grant',
                owner_scope    TEXT  NOT NULL DEFAULT 'grant',
                status         TEXT    NOT NULL DEFAULT 'active',
                created_at     TEXT    NOT NULL DEFAULT (datetime('now', 'localtime')),
                updated_at     TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
            );
            CREATE INDEX IF NOT EXISTS idx_user_role   ON user(role_id);
            CREATE INDEX IF NOT EXISTS idx_user_status ON user(status);
            """
        )
        # ── M20：储区主数据 + 仓库维度 + 混放开关 + 货品绑定货位 ──
        # zone.warehouse_id 为空表示全仓共享；库位 warehouse_id 与储区 warehouse_id
        # 必须一致（或储区共享），由 routes_location 校验。
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS zone (
                id                INTEGER PRIMARY KEY AUTOINCREMENT,
                code              TEXT    NOT NULL UNIQUE,
                name              TEXT    NOT NULL,
                warehouse_id      INTEGER REFERENCES warehouse(id),
                temp_class        TEXT    NOT NULL DEFAULT '常温',
                allow_mix_product INTEGER NOT NULL DEFAULT 0,
                allow_mix_batch   INTEGER NOT NULL DEFAULT 0,
                allow_mix_owner   INTEGER NOT NULL DEFAULT 0,
                status            TEXT    NOT NULL DEFAULT 'active',
                note              TEXT    NOT NULL DEFAULT '',
                created_at        TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
                updated_at        TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
            );
            CREATE INDEX IF NOT EXISTS idx_zone_warehouse ON zone(warehouse_id);
            CREATE INDEX IF NOT EXISTS idx_zone_status    ON zone(status);
            CREATE TABLE IF NOT EXISTS product_location (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                product_id  INTEGER NOT NULL REFERENCES product(id) ON DELETE CASCADE,
                location_id INTEGER NOT NULL REFERENCES location(id) ON DELETE CASCADE,
                priority    INTEGER NOT NULL DEFAULT 0,
                note        TEXT    NOT NULL DEFAULT '',
                created_at  TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
                UNIQUE(product_id, location_id)
            );
            CREATE INDEX IF NOT EXISTS idx_pl_product   ON product_location(product_id);
            CREATE INDEX IF NOT EXISTS idx_pl_location ON product_location(location_id);
            """
        )
        _migrate_m20_columns(conn)
        _migrate_scope_columns(conn)
        _migrate_m21_columns(conn)
        _migrate_m22(conn)
        _migrate_m23(conn)
        _migrate_m24(conn)
        _migrate_m25(conn)
        _migrate_m26(conn)
        _migrate_m35(conn)
        _migrate_m36(conn)
        _migrate_m37(conn)
        _migrate_m38(conn)
        _migrate_m41(conn)
        _migrate_m31(conn)
        _migrate_m32(conn)
        _migrate_m33(conn)
        _migrate_m34(conn)
        _migrate_abc(conn)
        _migrate_asn_counts(conn)
        _ensure_columns(conn, "dn", (
            ("target_warehouse", "INTEGER REFERENCES warehouse(id)"),
            ("transfer_asn_id", "INTEGER"),
            ("transfer_asn_code", "TEXT NOT NULL DEFAULT ''"),
            ("customer_name", "TEXT NOT NULL DEFAULT ''"),
            ("customer_contact", "TEXT NOT NULL DEFAULT ''"),
            ("customer_phone", "TEXT NOT NULL DEFAULT ''"),
            ("customer_address", "TEXT NOT NULL DEFAULT ''"),
            ("workflow_required", "INTEGER NOT NULL DEFAULT 0"),
        ))
        _ensure_columns(conn, "dn_line", (("extra", "TEXT NOT NULL DEFAULT ''"),))
        conn.execute("""
            UPDATE dn SET status = CASE WHEN EXISTS (
                SELECT 1 FROM dn_pick WHERE dn_id = dn.id AND wave_no != ''
            ) THEN ? ELSE ? END
            WHERE status = ? AND EXISTS (SELECT 1 FROM dn_line WHERE dn_id = dn.id)
            AND NOT EXISTS (
                SELECT 1 FROM dn_line WHERE dn_id = dn.id AND ordered_qty - picked_qty > 1e-9
            )
        """, (C.DN_ALLOCATED, C.DN_PICKED, C.DN_PICKING))
        conn.execute("""
            UPDATE dn SET status = ?
            WHERE status NOT IN (?, ?, ?) AND EXISTS (
                SELECT 1 FROM dn_review WHERE dn_id = dn.id AND status = ?
            )
        """, (C.DN_REVIEWED, C.DN_REVIEWED, C.DN_SHIPPED, C.DN_CANCELLED, C.REVIEW_COMPLETED))
        conn.execute("""
            UPDATE asn SET status = ?
            WHERE status = ? AND EXISTS (
                SELECT 1 FROM asn_line
                WHERE asn_line.asn_id = asn.id AND received_qty - putaway_qty > 1e-9
            )
        """, (C.ASN_PUTAWAY, C.ASN_CLOSED))
        _ensure_columns(conn, "putaway_recommendation", (
            ("receipt_barcode", "TEXT NOT NULL DEFAULT ''"),
        ))
        _ensure_columns(conn, "inventory_transfer_line", (
            ("from_batch_info", "TEXT NOT NULL DEFAULT ''"),
            ("to_batch_info", "TEXT NOT NULL DEFAULT ''"),
        ))
        _seed_zones(conn)
        PR.seed_rules(conn)
        _seed_auth(conn)
        conn.commit()
    finally:
        conn.close()


# ── 业务模块注册（须在 app/get_db 定义之后导入，供蓝图反向引用）──
# 仅在被 import 时注册蓝图；若以 `python main.py` 直接运行，__main__ 与 main
# 会形成双实例循环导入（routes_* → from main import ... → 再次执行本文件的
# 蓝图导入），因此入口模式下改为以 main 模块身份重新导入自身。
if __name__ == "__main__":
    from main import app as _app, init_db as _init_db  # noqa: E402

    _init_db()
    # 端口可用 MINIWMS_PORT 覆盖，便于本机多实例/端到端测试（默认仍为 5100）
    _app.run(host="0.0.0.0", port=int(os.environ.get("MINIWMS_PORT", "5100")), debug=False)
else:
    from routes_location import location_bp  # noqa: E402
    from routes_owner import owner_bp  # noqa: E402
    from routes_product import product_bp  # noqa: E402
    from routes_asn import asn_bp  # noqa: E402
    from routes_dn import dn_bp  # noqa: E402
    from routes_stock import stock_bp  # noqa: E402
    from routes_customer import customer_bp
    from routes_user import user_bp  # noqa: E402
    from routes_carrier import carrier_bp  # noqa: E402
    from routes_supplier import supplier_bp  # noqa: E402
    from routes_warehouse import warehouse_bp  # noqa: E402
    from routes_transfer import transfer_bp  # noqa: E402
    from routes_stocktake import stocktake_bp  # noqa: E402
    from routes_batch import batch_bp  # noqa: E402
    from routes_zone import zone_bp  # noqa: E402
    from routes_product_location import product_location_bp  # noqa: E402
    from routes_putaway import putaway_bp  # noqa: E402
    from routes_scope import scope_bp  # noqa: E402
    from routes_owner_warehouse import ow_bp  # noqa: E402
    from routes_stock_adjustment import adj_bp  # noqa: E402
    from routes_stocktake_plan import plan_bp  # noqa: E402
    from routes_reservation_log import log_bp  # noqa: E402
    from routes_inventory_transfer import it_bp  # noqa: E402
    from routes_putaway_rules import pr_bp  # noqa: E402
    from routes_outbound_allocation import oa_bp  # noqa: E402
    from routes_dn_review import rv_bp  # noqa: E402
    from routes_care import care_bp  # noqa: E402
    from routes_dn_order import dn_order_bp  # noqa: E402
    from routes_gsp import gsp_bp  # noqa: E402  M39 GSP 合规报表（纯只读）
    from routes_workload import workload_bp  # noqa: E402  M40 工作量统计（纯只读）
    from routes_print import print_bp  # noqa: E402  M41 打印模板 + PDF/预览
    from routes_fleet import fleet_bp  # noqa: E402  M31 司机/车辆主数据（编号后移补做）
    from routes_product_type import product_type_bp  # noqa: E402  M32 产品类型字典
    from routes_serial import serial_bp  # noqa: E402  M33 序列号台账
    from routes_abc import abc_bp  # noqa: E402  ABC 分类（补规则条件组数据源）
    from routes_location_group import location_group_bp  # noqa: E402  M34 货位组主数据
    from routes_operation_report import operation_report_bp  # noqa: E402  M28 经营报表

    app.register_blueprint(owner_bp)
    app.register_blueprint(product_bp)
    app.register_blueprint(location_bp)
    app.register_blueprint(asn_bp)
    app.register_blueprint(dn_bp)
    app.register_blueprint(stock_bp)
    app.register_blueprint(customer_bp)
    app.register_blueprint(user_bp)
    app.register_blueprint(carrier_bp)
    app.register_blueprint(supplier_bp)
    app.register_blueprint(warehouse_bp)
    app.register_blueprint(transfer_bp)
    app.register_blueprint(stocktake_bp)
    app.register_blueprint(batch_bp)
    app.register_blueprint(zone_bp)
    app.register_blueprint(product_location_bp)
    app.register_blueprint(putaway_bp)
    app.register_blueprint(scope_bp)
    app.register_blueprint(ow_bp)
    app.register_blueprint(adj_bp)
    app.register_blueprint(plan_bp)
    app.register_blueprint(log_bp)
    app.register_blueprint(it_bp)
    app.register_blueprint(pr_bp)
    app.register_blueprint(oa_bp)
    app.register_blueprint(rv_bp)
    app.register_blueprint(care_bp)
    app.register_blueprint(dn_order_bp)
    app.register_blueprint(gsp_bp)
    app.register_blueprint(workload_bp)
    app.register_blueprint(print_bp)
    app.register_blueprint(fleet_bp)
    app.register_blueprint(product_type_bp)
    app.register_blueprint(serial_bp)
    app.register_blueprint(abc_bp)
    app.register_blueprint(location_group_bp)
    app.register_blueprint(operation_report_bp)
