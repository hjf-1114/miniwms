"""货主主数据模块：/api/owners 的增删改查。

多货主（3PL）是 WMS 的核心模型：每个货主拥有独立的物料档案与库存，
后续收货/拣货/库存账/盘点等所有单据都挂 owner 维度。
M2 先落地货主主数据，并把物料挂接到货主。
"""
import sqlite3

import scope as S
from flask import Blueprint, jsonify, request

from main import get_control_db, request_payload

owner_bp = Blueprint("owner", __name__, url_prefix="/api/owners")

DEFAULT_PAGE_SIZE = 20
MAX_PAGE_SIZE = 100


def _validate_owner_payload(payload, *, partial=False):
    """校验货主字段。partial=True 只校验出现过的字段。返回 (errors, cleaned)。"""
    errors = []
    cleaned = {}

    if "code" in payload or not partial:
        code = str(payload.get("code") or "").strip()
        if not code:
            errors.append("code 必填")
        elif len(code) > 32:
            errors.append("code 最长 32 字符")
        else:
            cleaned["code"] = code

    if "name" in payload or not partial:
        name = str(payload.get("name") or "").strip()
        if not name:
            errors.append("name 必填")
        elif len(name) > 128:
            errors.append("name 最长 128 字符")
        else:
            cleaned["name"] = name

    if "contact" in payload:
        cleaned["contact"] = str(payload.get("contact") or "").strip()

    if "phone" in payload:
        cleaned["phone"] = str(payload.get("phone") or "").strip()

    if "email" in payload:
        cleaned["email"] = str(payload.get("email") or "").strip()

    if "address" in payload:
        cleaned["address"] = str(payload.get("address") or "").strip()

    if "status" in payload:
        status = str(payload.get("status") or "").strip()
        if status not in ("active", "inactive"):
            errors.append("status 只能是 active/inactive")
        else:
            cleaned["status"] = status

    if "note" in payload:
        cleaned["note"] = str(payload.get("note") or "")

    # M11 电商/3PL 级字段
    for key in ("province", "city", "district", "backup_address", "authorized_warehouse", "business_scope", "extra1", "extra2"):
        if key in payload:
            cleaned[key] = str(payload.get(key) or "").strip()

    # M15 合作起止时间
    if "start_date" in payload:
        cleaned["start_date"] = str(payload.get("start_date") or "").strip()
    if "end_date" in payload:
        cleaned["end_date"] = str(payload.get("end_date") or "").strip()

    return errors, cleaned


def _code_exists(db, code, exclude_id=None):
    sql = "SELECT id FROM owner WHERE code = ?"
    params = [code]
    if exclude_id is not None:
        sql += " AND id != ?"
        params.append(exclude_id)
    return db.execute(sql, params).fetchone() is not None


@owner_bp.route("", methods=["POST"])
def create_owner():
    errors, cleaned = _validate_owner_payload(request_payload(), partial=False)
    if errors:
        return jsonify({"ok": False, "errors": errors}), 400

    db = get_control_db()
    if _code_exists(db, cleaned["code"]):
        return jsonify({"ok": False, "errors": [f"货主编码已存在: {cleaned['code']}"]}), 409

    cur = db.execute(
        """INSERT INTO owner (code, name, contact, phone, email, address, status, note,
                              province, city, district, backup_address, authorized_warehouse,
                              business_scope, start_date, end_date, extra1, extra2)
           VALUES (:code, :name, :contact, :phone, :email, :address, :status, :note,
                   :province, :city, :district, :backup_address, :authorized_warehouse,
                   :business_scope, :start_date, :end_date, :extra1, :extra2)""",
        {
            **cleaned,
            "contact": cleaned.get("contact", ""),
            "phone": cleaned.get("phone", ""),
            "email": cleaned.get("email", ""),
            "address": cleaned.get("address", ""),
            "status": cleaned.get("status", "active"),
            "note": cleaned.get("note", ""),
            "province": cleaned.get("province", ""),
            "city": cleaned.get("city", ""),
            "district": cleaned.get("district", ""),
            "backup_address": cleaned.get("backup_address", ""),
            "authorized_warehouse": cleaned.get("authorized_warehouse", ""),
            "business_scope": cleaned.get("business_scope", ""),
            "start_date": cleaned.get("start_date", ""),
            "end_date": cleaned.get("end_date", ""),
            "extra1": cleaned.get("extra1", ""),
            "extra2": cleaned.get("extra2", ""),
        },
    )
    db.commit()
    row = db.execute("SELECT * FROM owner WHERE id = ?", (cur.lastrowid,)).fetchone()
    return jsonify({"ok": True, "owner": dict(row)}), 201


@owner_bp.route("", methods=["GET"])
def list_owners():
    args = request.args
    keyword = (args.get("keyword") or "").strip()
    status = (args.get("status") or "").strip()
    try:
        page = max(1, int(args.get("page", 1)))
        page_size = min(MAX_PAGE_SIZE, max(1, int(args.get("page_size", DEFAULT_PAGE_SIZE))))
    except ValueError:
        return jsonify({"ok": False, "errors": ["page/page_size 必须为整数"]}), 400

    where, params = [], []
    if keyword:
        where.append("(code LIKE ? OR name LIKE ?)")
        params += [f"%{keyword}%", f"%{keyword}%"]
    if status:
        where.append("status = ?")
        params.append(status)
    S.scoped_where(where, params, column="id")
    where_sql = ("WHERE " + " AND ".join(where)) if where else ""

    db = get_control_db()
    total = db.execute(f"SELECT COUNT(*) AS n FROM owner {where_sql}", params).fetchone()["n"]
    rows = db.execute(
        f"SELECT * FROM owner {where_sql} ORDER BY id DESC LIMIT ? OFFSET ?",
        params + [page_size, (page - 1) * page_size],
    ).fetchall()
    return jsonify(
        {
            "ok": True,
            "total": total,
            "page": page,
            "page_size": page_size,
            "owners": [dict(r) for r in rows],
        }
    )


@owner_bp.route("/<int:owner_id>", methods=["GET"])
def get_owner(owner_id):
    row = get_control_db().execute("SELECT * FROM owner WHERE id = ?", (owner_id,)).fetchone()
    if row is None:
        return jsonify({"ok": False, "error": "货主不存在"}), 404
    return jsonify({"ok": True, "owner": dict(row)})


@owner_bp.route("/<int:owner_id>", methods=["PUT"])
def update_owner(owner_id):
    errors, cleaned = _validate_owner_payload(request_payload(), partial=True)
    if errors:
        return jsonify({"ok": False, "errors": errors}), 400
    if not cleaned:
        return jsonify({"ok": False, "errors": ["没有可更新的字段"]}), 400

    db = get_control_db()
    if db.execute("SELECT id FROM owner WHERE id = ?", (owner_id,)).fetchone() is None:
        return jsonify({"ok": False, "error": "货主不存在"}), 404
    if "code" in cleaned and _code_exists(db, cleaned["code"], exclude_id=owner_id):
        return jsonify({"ok": False, "errors": [f"货主编码已存在: {cleaned['code']}"]}), 409

    set_sql = ", ".join(f"{k} = :{k}" for k in cleaned)
    cleaned["id"] = owner_id
    db.execute(
        f"UPDATE owner SET {set_sql}, updated_at = datetime('now', 'localtime') WHERE id = :id",
        cleaned,
    )
    db.commit()
    row = db.execute("SELECT * FROM owner WHERE id = ?", (owner_id,)).fetchone()
    return jsonify({"ok": True, "owner": dict(row)})


@owner_bp.route("/<int:owner_id>", methods=["DELETE"])
def delete_owner(owner_id):
    db = get_control_db()
    if db.execute("SELECT id FROM owner WHERE id = ?", (owner_id,)).fetchone() is None:
        return jsonify({"ok": False, "error": "货主不存在"}), 404
    # 货主是跨仓主数据，物料却分布在各仓业务库，删除前必须逐个库检查引用
    import sqlite3

    from main import all_business_db_paths

    n = 0
    for path in all_business_db_paths(db):
        conn = sqlite3.connect(path)
        try:
            n += conn.execute(
                "SELECT COUNT(*) AS n FROM product WHERE owner_id = ?", (owner_id,)
            ).fetchone()[0]
        finally:
            conn.close()
    if n:
        return jsonify(
            {"ok": False, "error": f"该货主名下还有 {n} 个物料档案，禁止删除；请先转移或停用"}
        ), 409
    db.execute("DELETE FROM owner WHERE id = ?", (owner_id,))
    db.commit()
    return jsonify({"ok": True})


# ── M11 货主证照（营业执照/医疗器械经营许可等，可多证）──
@owner_bp.route("/<int:owner_id>/certs", methods=["GET"])
def list_owner_certs(owner_id):
    db = get_control_db()
    if db.execute("SELECT id FROM owner WHERE id = ?", (owner_id,)).fetchone() is None:
        return jsonify({"ok": False, "error": "货主不存在"}), 404
    rows = db.execute(
        "SELECT * FROM owner_cert WHERE owner_id = ? ORDER BY id", (owner_id,)
    ).fetchall()
    return jsonify({"ok": True, "certs": [dict(r) for r in rows]})


@owner_bp.route("/<int:owner_id>/certs", methods=["POST"])
def add_owner_cert(owner_id):
    payload = request_payload()
    cert_type = str(payload.get("cert_type") or "").strip()
    if not cert_type:
        return jsonify({"ok": False, "errors": ["cert_type 必填"]}), 400
    cert_no = str(payload.get("cert_no") or "").strip()
    issuer = str(payload.get("issuer") or "").strip()
    valid_from = str(payload.get("valid_from") or "").strip()
    valid_to = str(payload.get("valid_to") or "").strip()
    note = str(payload.get("note") or "").strip()
    db = get_control_db()
    if db.execute("SELECT id FROM owner WHERE id = ?", (owner_id,)).fetchone() is None:
        return jsonify({"ok": False, "error": "货主不存在"}), 404
    cur = db.execute(
        """INSERT INTO owner_cert (owner_id, cert_type, cert_no, issuer, valid_from, valid_to, note)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (owner_id, cert_type, cert_no, issuer, valid_from, valid_to, note),
    )
    db.commit()
    row = db.execute("SELECT * FROM owner_cert WHERE id = ?", (cur.lastrowid,)).fetchone()
    return jsonify({"ok": True, "cert": dict(row)}), 201


@owner_bp.route("/<int:owner_id>/certs/<int:cert_id>", methods=["DELETE"])
def delete_owner_cert(owner_id, cert_id):
    db = get_control_db()
    if db.execute(
        "SELECT id FROM owner_cert WHERE id = ? AND owner_id = ?", (cert_id, owner_id)
    ).fetchone() is None:
        return jsonify({"ok": False, "error": "证照不存在"}), 404
    db.execute("DELETE FROM owner_cert WHERE id = ?", (cert_id,))
    db.commit()
    return jsonify({"ok": True})
